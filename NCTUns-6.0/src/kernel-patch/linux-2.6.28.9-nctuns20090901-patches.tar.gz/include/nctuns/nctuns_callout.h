#ifndef __nctuns_callout_h__
#define __nctuns_callout_h__

#include <linux/timer.h>

#define 	callwheelsize 	8192
#define 	callwheelmask 	(callwheelsize - 1)

struct callwheel {
	struct list_head vec[callwheelsize];
	int count;
};

void nctuns_callout_helper(struct timer_list *, long);
void nctuns_clear_callwheel(void);
int nctuns_callback(void);
int check_if_nctuns_timer(struct timer_list *);

extern struct callwheel callwheel;

#endif /* __nctuns_callout_h__ */
