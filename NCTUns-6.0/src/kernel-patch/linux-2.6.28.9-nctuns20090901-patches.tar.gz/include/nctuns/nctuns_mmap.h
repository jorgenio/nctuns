#ifndef __nctuns_mmap_h
#define __nctuns_mmap_h

/*
 * The virtual clock of nodes. In the current version, we use only node 0's
 * clock as the whole simulation system's clock.
 */
extern u64		*NCTUNS_nodeVC;

/*
 * the current nctuns and event tunnel queue length, the NCTUns engine just
 * read only
 */
extern uint32_t 	*tunif_qlen;
extern uint32_t 	*ce_tun_qlen;

/*
 * the current fifo queue length and max queue length of NCTUns engine, the
 * kernel just read only
 */
extern uint32_t 	*fifoIFmaxqlen;
extern uint32_t 	*fifoIFcurqlen;

#endif /* __nctuns_mmap_h */
