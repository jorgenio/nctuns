#ifndef __nctuns_tun_h
#define __nctuns_tun_h

#include <linux/types.h>
#include <linux/netdevice.h>
#include <linux/if.h>

#define EVENT_TUN_NAME	"ce_tun"
#define EVENT_TUN_ID	5000

struct tun_event {
	int pid;
	u_int32_t nid;
	int flag;
	u_int64_t value;
	int socket_fd;
};

enum tun_event_flag_enum {
	T0E_TIMEOUT	= 0x01,
	T0E_CHKTUN,
	T0E_CHK_CMDIPC,
	T0E_NOTICE_CHILD_PGID
};

/*
 * Examine the sock is the nctuns sock
 */
static inline int is_nctuns_tun_dev(const struct net_device *dev)
{
	return (dev->flags & IFF_POINTOPOINT) && !(dev->flags & IFF_MULTICAST);
};

#endif /*__nctuns_tun_h */
