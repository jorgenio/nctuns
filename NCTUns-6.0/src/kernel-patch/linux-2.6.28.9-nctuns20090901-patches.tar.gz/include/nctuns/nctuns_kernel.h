#ifndef __nctuns_kernel_h
#define __nctuns_kernel_h

/*
 * The maximum number of tunnel interfaces to be simulated, can be
 * increased if needed. This number should be consistent with that
 * defined and used by the simulation engine.
 */
#define MAX_NUM_IF_TUN	4096
#define MAX_NUM_TUN	MAX_NUM_IF_TUN + 1

/*
 * The maximum number of nodes to be simulated, can be
 * increased if needed. This number should be consistent with that
 * defined and used by the simulation engine.
 */
#define MAX_NUM_NODE	4096

/*
 * Integrated kernel message for nctuns
 */
#define Nprintk_err(format, arg...)		\
	printk(KERN_ERR "NCTUns: [%s] " format, __func__, ##arg)

#define Nprintk_warning(format, arg...)		\
	printk(KERN_WARNING "NCTUns: [%s] " format, __func__, ##arg)

#define Nprintk_info(format, arg...)		\
	printk(KERN_INFO "NCTUns: " format, ##arg)

#define Nprintk_debug(format, arg...)		\
	printk(KERN_DEBUG "NCTUns: [%s:%d<%s>] " format, __FILE__, __LINE__, __func__, ##arg)

#endif /* __nctuns_kernel_h */
