#ifndef __nctuns_sock_h
#define __nctuns_sock_h

#include <nctuns/nctuns_kernel.h>
#include <net/sock.h>

/*
 * return the nodeID of sock_struct
 */
#define nctuns_sock_node_id(sk)		(sk)->nctuns_sock.nodeID

/*
 * Examine the sock is the nctuns sock
 */
static inline int is_nctuns_sock(const struct sock *sk)
{
	return (sk && nctuns_sock_node_id(sk)) ? 1 : 0;
};

/*
 * Examine this sock and nodeID is valid
 */
static inline int is_nctuns_valid_sock(struct sock *sk)
{
	return nctuns_sock_node_id(sk) && nctuns_sock_node_id(sk) <= MAX_NUM_NODE;
};

#endif /*__nctuns_sock_h */
