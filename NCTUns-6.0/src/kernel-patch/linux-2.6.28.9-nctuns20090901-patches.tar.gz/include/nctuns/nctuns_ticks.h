#ifndef __nctuns_ticks_h
#define __nctuns_ticks_h

#include <linux/math64.h>

/* 
 * the instance of following variable in nctuns_mmap.c
 */
extern uint64_t *NCTUNS_nodeVC;
extern uint32_t microscale;

/*
 * Parameters used to convert the nctuns ticks:
 */
#define NCTUNS_TICKS_PER_SEC	(1000000 * microscale)
#define NCTUNS_TICKS_PER_MSEC	(1000 * microscale)
#define NCTUNS_TICKS_PER_USEC	(microscale)
#define NSEC_PER_NCTUNS_TICKS	(1000 / microscale)

/*
 * NCTUNS_ticks is mini-second.
 */
#define NCTUNS_ticks_to_ns \
	(NCTUNS_nodeVC[0] * NSEC_PER_NCTUNS_TICKS)

#define NCTUNS_ticks_to_us \
	div64_u64(NCTUNS_nodeVC[0], NCTUNS_TICKS_PER_USEC)

#define NCTUNS_ticks_to_ms \
	div64_u64(NCTUNS_nodeVC[0], NCTUNS_TICKS_PER_MSEC)

#define NCTUNS_ticks_to_sec \
	div64_u64(NCTUNS_nodeVC[0], NCTUNS_TICKS_PER_SEC)

#define NCTUNS_ticks 		(long)NCTUNS_ticks_to_ms
#define NCTUNS_tcp_time_stamp 	(long)NCTUNS_ticks_to_ms
#define NCTUNS_xtime_tvsec 	(time_t)NCTUNS_ticks_to_sec

#endif /* __nctuns_ticks_h */
