#ifndef __nctuns_sched_h
#define __nctuns_sched_h

#include <linux/sched.h>

/* 
 * the instance of following variable in nctuns_mmap.c
 */
extern pid_t nctuns;

/*
 * return the nodeID of task_struct
 */
#define nctuns_task_node_id(tsk)		(tsk)->nctuns_task.nodeID

/*
 * Examine the nctuns engine whether is running
 */
static inline int is_nctuns_engine_in_task_queue(void)
{
	extern pid_t nctuns;

	/*
	 * When the nctuns engine starts, it should call the syscall to
	 * initialize all state of kernel variables, and the syscall also keep
	 * the nctuns pid value in variable, nctuns. But, if it more than zero,
	 * it's not meaning the engine is running, because of the engine
	 * simulated done, this variable maybe not be changed. So we need check
	 * whether the nctuns task is in the task queue currently
	 */
	return nctuns > 0 && find_task_by_pid_ns(nctuns, &init_pid_ns);
};

/*
 * Examine the task is the nctuns task
 */
static inline int is_nctuns_task(const struct task_struct *tsk)
{
	return (tsk && nctuns_task_node_id(tsk)) ? 1 : 0;
}
#endif /*__nctuns_sched_h */
