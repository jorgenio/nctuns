#ifndef	__nctuns_maptable_h__
#define	__nctuns_maptable_h__

#include <linux/types.h>
#include <linux/socket.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/inetdevice.h>
#include <linux/if_tun.h>

#include <net/sock.h>

#include <linux/list.h>

/*=====================================================================
   Define Macros
  =====================================================================*/
#define ENDPORT			65535
#define START_PORT		5001
#define LAST_PORT		65534
#define START_AUTO_LO		1024
#define START_AUTO_HIGH		5000
#define PORT_SIZE               65534-5000
               
enum maptable_action_enum {
	syscall_NSC_mt_ADD = 0x01,
	syscall_NSC_mt_FLUSH,
	syscall_NSC_mt_DISPLAY
};

struct if_info {
	struct hlist_node	entry;

	unsigned long		tunid;	/* tunnel ID */
	__u32			tunip;	/* tunnel IP */
	__u8			mac[6];	/* tunnel MAC */
	struct in_ifaddr	*ifa;	/* tunnel ip address linked list */
}; 

/* used to port mapping */
struct pmap_info {
	struct hlist_node	entry;

	struct proto		*prot;	/* protocol type */
	__u16			rport;	/* real port */
	__u16			vport;	/* virtual port */
	/*
	 * linked list of all sk which be transformed virtual port to real port
	 */
	struct hlist_head	owner;
};

 
struct node_info {
	struct list_head	entry;
	
	unsigned long		nodeID;	/* node ID */
	unsigned int		numif;	/* number of interfaces */ 
	struct hlist_head	if_info;
	
	__u16			s_port;	/* start port range */
	__u16			lastport;	/* last useful port number */
	struct hlist_head	pmap_info;
};  

int 		mt_init			(void); 
int 		mt_free			(void);
int 	 	mt_add			(unsigned long, unsigned long, __u8 *, __u16);
int		mt_nidifinfo		(unsigned long, int, char *);
unsigned long	mt_tidtonid		(unsigned long);
unsigned long	mt_iptonid		(__u32);
unsigned long	mt_iptonid_by_ifa	(__u32, struct net_device*);
unsigned long	mt_ipcmp_nid		(__u32, __u32);
__u32		mt_tidtoip		(unsigned long);
__u32		mt_randnidtoip		(unsigned long, __u32);
__u16		mt_VtoRport		(unsigned long, struct proto *, __u32, __u16);
__u16		mt_RtoVport		(struct proto *, __u16);

/* port manipulation */
int		mt_bind			(struct sock *);
int	 	mt_unbind		(struct sock *);
__u16		mt_getunuseVport	(struct sock *);
void		mt_display		(void);
int		mt_nidtotid		(unsigned long, int, unsigned long *);
unsigned long	mt_tidnum		(unsigned long);
unsigned long	mt_gettidbyname		(char *);

int		mt_get_port		(struct sock *, unsigned short snum);

void 		mt_getipprefix		(__u32 *postfix);

#endif	/* __nctuns_maptable_h__ */



