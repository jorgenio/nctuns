#ifndef __nctuns_syscall_h__
#define __nctuns_syscall_h__

enum syscall_NSC_misc_enum {
	syscall_NSC_misc_TEST = 0x01,
	syscall_NSC_misc_GETNIDINFO,
	syscall_NSC_misc_REGPID,
	syscall_NSC_misc_SET_ENDTIME,
	syscall_NSC_misc_NIDTOTID,
	syscall_NSC_misc_NIDNUM,
	syscall_NSC_misc_R2VPORT,
	syscall_NSC_misc_V2RPORT,
	syscall_NSC_misc_TICKTONANO,
	syscall_NSC_misc_SET_TUN,
	syscall_NSC_misc_GET_TUN,
	syscall_NSC_misc_PIDTONID
};

/*
 * this struct which be used by syscall_NCTUNS_misc, and action equal R2VPORT
 * or V2RPORT
 */
struct syscall_port_info {
	int		prot;	/* protocol type */
	__u32		ip;	/* interface ip */
	__u16		rport;	/* real port */
	__u16		vport;	/* virtual port */
};

#endif /* __nctuns_syscall_h__ */
