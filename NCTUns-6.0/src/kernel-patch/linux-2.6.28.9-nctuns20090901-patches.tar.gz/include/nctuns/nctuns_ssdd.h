#ifndef __nctuns_ssdd_h
#define __nctuns_ssdd_h

#include <linux/types.h>
//wghuang
#include <nctuns/nctuns_maptable.h>
/////////

/*
 * If the socket flow is flowing in NCTUns interval topology (not external
 * topology), the IP must be 1.0.X.X
 */
static inline int is_nctuns_internal_ip_scheme(__u32 ip)
{
	return (ip & __constant_htonl(0xFFFF0000)) == __constant_htonl(0x01000000);
};

/*
 * The NCTUns IP scheme of kernel is S.S.D.D, so we can find the source and
 * destination IP from the SSDD IP.
 */
static inline void nctuns_convert_ssdd_to_src(__u32 *ssdd)
{
	/*
	 * If the IP is 1.2.3.4, then the network order of the 32bits integer
	 * value is 0x01020304. However, the host order of linux system is
	 * reversal of the network order so that the value is 0x04030201.
	 *
	 * If we want to get the source ip, than we can shift 16bits to left.
	 * In the host order, the value is 0x02010000. In the network order,
	 * the value is 0x00000102. Second, OR the 0x0001 value make the IP
	 * become from 0.0.S.S to 1.0.S.S
	 */
	(*ssdd) <<= 16;
	*ssdd &= 0xFFFF0000;
	mt_getipprefix(ssdd);
	//printk("src:%u\n" , *ssdd);
	//*ssdd |= 0x0001;
};

static inline void nctuns_convert_ssdd_to_dst(__u32 *ssdd)
{
	/*
	 * If the IP is 1.2.3.4, then the network order of the 32bits integer
	 * value is 0x01020304. However, the host order of linux system is
	 * reversal of the network order so that the value is 0x04030201.
	 *
	 * If we want to get the destination ip, than we can AND the right
	 * 16bits with zero, In the host order, the value is 0x04030000. In the
	 * network order, the value is 0x00000304. Second, or the 0x0001 value
	 * make the IP become from 0.0.D.D to 1.0.D.D
	 */
	*ssdd &= 0xFFFF0000;
	mt_getipprefix(ssdd);
	//printk("dst:%u\n" , *ssdd);
	//*ssdd |= 0x0001;
};

/*
 * The NCTUns IP scheme of kernel is S.S.D.D. If we want to combine a SSDD IP,
 * we need source and destination IP.
 */
static inline __u32 nctuns_convert_ip_to_ssdd(__u32 src_ip, __u32 dst_ip)
{
	/*
	 * If the IP is 1.2.3.4, then the network order of the 32bits integer
	 * value is 0x01020304. However, the host order of linux system is
	 * reversal of the network order so that the value is 0x04030201.
	 *
	 * If the source IP is 1.0.1.2, the destination IP is 1.0.3.4
	 *
	 * First, we can get the left 16bits of destination IP, then the value
	 * is 0x04030000 in host order. It's meaning 0.0.D.D.
	 *
	 * Second, we need get the left 16bits of source IP and let shift
	 * 16bits to right, so that the value becomes 0x00000201 in host order.
	 * It's meaning S.S.0.0
	 *
	 * Third, OR two value so that the value is 0x04030201 in host order
	 * and 0x01020304 in network order
	 */
	return (dst_ip & 0xFFFF0000) | ((src_ip >> 16) & 0xFFFF);
};

#endif /*__nctuns_ssdd_h */
