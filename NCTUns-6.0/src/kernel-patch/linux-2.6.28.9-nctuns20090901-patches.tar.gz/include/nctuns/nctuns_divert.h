#ifndef	__nctuns_divert_h__
#define	__nctuns_divert_h__

enum divert_action_enum {
	syscall_NSC_divert_INFO = 0x01,
	syscall_NSC_divert_FLUSH,
	syscall_NSC_divert_ADDHEAD,
	syscall_NSC_divert_ADDTAIL,
	syscall_NSC_divert_DELETE,
	syscall_NSC_divert_MOVETAIL
};

struct divert_rule {
	int	 	proto;
	u_long		srcip;
	u_long		smask;
	u_long		dstip;
	u_long		dmask;
	u_long		sport;
	u_long		dport;
};

struct divert_entry {
	struct divert_rule	rule;

	struct sock		*sk;
	u_long			hook;
	struct list_head 	entry;
};

static inline struct divert_rule *divert_rl(const struct divert_entry *entry)
{
	return (struct divert_rule *)entry;
};

int nctuns_reg_divert_rule(enum divert_action_enum action, struct sock *sk, u_long hook, struct divert_rule __user *user_dr, int addr_len);

#endif /* __nctuns_redirect_h__ */
