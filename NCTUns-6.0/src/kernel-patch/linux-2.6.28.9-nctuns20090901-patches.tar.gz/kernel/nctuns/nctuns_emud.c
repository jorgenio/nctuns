/*
 * NCTUns Emulation Daemon in Kernel Space v 0.3
 * 2008/04/21
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/netfilter_ipv4.h>
#include <linux/kthread.h>
#include <asm/uaccess.h>

#include <net/ip.h>
#include <net/checksum.h>
#include <linux/skbuff.h>
#include <linux/inet.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>

#include <nctuns/nctuns_ssdd.h>
#include <nctuns/nctuns_tun.h>

#define DRIVER_NAME	"NCTUnsEmud"

#define MAX_IF		128
#define PROCFS_MAX_SIZE	2048
#define PROCFS_NAME	"nctuns_emud"
#define TO_EMU		0
#define TO_EXT		1

// Binding Table: For internal IP and externel IP Mapping
struct binding {
	unsigned int intIP;
	unsigned int extIP;
} iptab[MAX_IF], routerIF[MAX_IF];

static int iptab_count, routerIF_count;		// binding table count
static struct nf_hook_ops nfho;			// for set a hook in ip_rcv
static struct proc_dir_entry* emud_proc_file;	// procfs set up variable
static char procfs_buf[PROCFS_MAX_SIZE];	// procfs buffer
extern int nctuns_emu_module;

// TCP/UDP checksum calculation
static unsigned short tu_chk(int len, int protocol, unsigned char* saddr, unsigned char* daddr, unsigned char* tuhdr)
{
	int sum=0, i;
	unsigned short word16;

	// calculate TCP/UDP Header and data checksum
	for(i=0;i<len;i+=2)
	{
		if(i+2 > len && len % 2)
			word16 = tuhdr[i] << 8;
		else
			word16 = (tuhdr[i] << 8) | tuhdr[i+1];
		sum += word16;
	}

	// Process source IP, destinate IP, protocol and length.
	word16 = (saddr[0] << 8) | saddr[1];
	sum += word16;
	word16 = (saddr[2] << 8) | saddr[3];
	sum += word16;

	word16 = (daddr[0] << 8) | daddr[1];
	sum += word16;
	word16 = (daddr[2] << 8) | daddr[3];
	sum += word16;

	sum += protocol;
	sum += len;

	// merge the sum into unsigned 16-bit integral
	while(sum >> 16)
		sum = (sum & 0xFFFF) + (sum >> 16);
	word16 = (unsigned short)(sum);

	return htons((unsigned short)(~sum));
}

// CalChecksum:
// 	Calculate IP/TCP/UDP checksum of a packet.
static int CalChecksum(struct iphdr* iph)
{
	int len = 0;
	struct tcphdr* tcph=NULL;
	struct udphdr* udph=NULL;
	unsigned char* buf;

	// Calculate ip header checksum.
	iph->check = 0;
	iph->check = ip_fast_csum((void*)iph, iph->ihl);

	// if the packet is a TCP/UDP packet, calculate TCP/UDP checksum.
	if(iph->protocol == IPPROTO_TCP || iph->protocol == IPPROTO_UDP)
	{
		// Get the length except IP header.
		len = ntohs(iph->tot_len) - iph->ihl * 4;

		// "Where is transport header?"
		buf = (unsigned char*)iph;
		buf += (iph->ihl*4);

		switch(iph->protocol)
		{
		case IPPROTO_TCP:
			tcph = (struct tcphdr*)buf;
			tcph->check = 0;
			tcph->check = tu_chk(len,
					IPPROTO_TCP,
					(unsigned char*)&(iph->saddr),
					(unsigned char*)&(iph->daddr),
					buf);
			break;
		case IPPROTO_UDP:
			udph = (struct udphdr*)buf;
			udph->check = 0;
			udph->check = tu_chk(len,
					IPPROTO_UDP,
					(unsigned char*)&(iph->saddr),
					(unsigned char*)&(iph->daddr),
					buf);
			break;
		}
	}

	return 0;
}

// Lookup if there has the same IP in the binding table.
static int CheckSrc(struct sk_buff* skb)
{
	struct iphdr* iph = (struct iphdr*)(skb->network_header);
	int id;

	struct in_device* in_dev = NULL;
	struct in_ifaddr* ifa = NULL;
	unsigned int ifip = 0;

	// determine whether the packet is for an emulation case.
	if((iph->daddr & 0xFF) != 1)
		goto src_router;

	if(!iptab_count) goto src_router;

	// search if there is any matched ip.
	for(id = 0; id < iptab_count; ++id)
	{
		// found... modify ip and calculate checksum
		if(iph->saddr == iptab[id].extIP)
		{
			iph->saddr = iptab[id].intIP;
			iph->daddr = nctuns_convert_ip_to_ssdd(iph->saddr, 
								iph->daddr);
			CalChecksum(iph);
			return 0;
		}
	}

src_router:
	if(!routerIF_count)
		return 1;

	// Check if source ip and destinate ip is from the router
	if((iph->saddr & 0xFF) != 200 || (iph->daddr & 0xFF) != 200)
		return -1;

	// get the ip of interfaces
	in_dev = in_dev_get(skb->dev);
	if(!in_dev || !(ifa = in_dev->ifa_list))
		return -1;
	ifip = ifa->ifa_local;

	for(id = 0; id < routerIF_count; ++id)
	{
		if(ifip == routerIF[id].extIP)
		{
			iph->saddr = nctuns_convert_ip_to_ssdd(routerIF[id].intIP, iph->saddr);
			iph->daddr = nctuns_convert_ip_to_ssdd(routerIF[id].intIP, iph->daddr);
			CalChecksum(iph);
			return 0;
		}
	}

	return -1;
}

// Lookup if there has the same IP in the binding table.
static int CheckDst(struct sk_buff* skb)
{
	struct iphdr* iph = (struct iphdr*)(skb->network_header);
	int id;
	unsigned int cmpIP=0;
	unsigned int subnet;

	// determine whether the packet is for an emulation case.
	if((iph->daddr & 0xFF) != 1)
		goto dst_router;

	if(!iptab_count) goto dst_router;

	// search if there is any matched ip.
	for(id = 0; id < iptab_count; ++id)
	{
		// found... modify ip and calculate checksum
		if(iph->daddr == iptab[id].intIP)
		{
			iph->saddr = ((iph->saddr) & 0xFFFF0000) | 0x1;
			iph->daddr = iptab[id].extIP;

			CalChecksum(iph);
			return 0;
		}
	}

dst_router:
	if(!routerIF_count)
		return 1;

	// Check if the packet is for router.
	if((iph->daddr & 0xFFFF) != (iph->saddr & 0xFFFF))
		return -1;

	// Get the ip to compare if the ip is in router
	cmpIP = ((iph->daddr & 0x0000FFFF) << 16) | 0x1;
	for(id = 0; id < routerIF_count; ++id)
	{
		// found... modify ip into 200.Z.X.Y
		if(cmpIP == routerIF[id].intIP)
		{
			subnet = ((iph->saddr & 0x00FF0000) >> 8) | 0xC8;
			iph->saddr = (iph->saddr & 0xFFFF0000) | subnet;
			iph->daddr = (iph->daddr & 0xFFFF0000) | subnet;

			CalChecksum(iph);
			return 0;
		}
	}

	return -1;
}

// Hook function: packet enter to this function after it is processed by ip_rcv
unsigned int IP_Recv_Hook(unsigned int hooknum, struct sk_buff* skb,
	const struct net_device* in, const struct net_device* out,
	int (*okfn)(struct sk_buff*))
{
	int ret;

	// there has no data in the binding table...
	if(!iptab_count && !routerIF_count) return NF_ACCEPT;

	// Check if ip data is matched with the data in the binding table.
	if( is_nctuns_tun_dev( skb->dev ) )
		ret = CheckDst(skb);
	else
		ret = CheckSrc(skb);

	return NF_ACCEPT;
}

// Get information from the binding table
int procfile_read(char* buffer, char** buffer_location, off_t offset, 
		int buffer_length, int* eof, void* data)
{
	int id;
	int i;

	if(offset > 0)
		return 0;

	i=0;
	// list data which are in the binding table
	for(id = 0; id < iptab_count; ++id)
	{
		if(i > 2000)
			break;

		i += sprintf(&procfs_buf[i],"ExtHost ID = %d IntIP = %08X, ExtIP = %08X \r",id,iptab[id].intIP,iptab[id].extIP);
		procfs_buf[i++] = 10;
	}

	for(id = 0; id < routerIF_count; ++id)
	{
		if(i > 2000) {
			i += sprintf(&procfs_buf[i], "Skip for more detail...\n");
			break;
		}
		i += sprintf(&procfs_buf[i],"ExtRouter ID = %d IntIP = %08X, ExtIP = %08X\r", id, routerIF[id].intIP, routerIF[id].extIP);
		procfs_buf[i++] = 10;
	}

	if(!iptab_count && !routerIF_count)
		i += sprintf(procfs_buf, "There has no data...\n");

	*buffer_location = procfs_buf;

	return i;
}

// insert a new data into the binding table,
// you can use echo in commandline or use write in program.
// syntax:
//   1.  insert External_IP Internal_IP
//   2.  router External_IP Internal_IP
//   3.  clear
// ex. echo insert 10.0.0.2 1.0.1.1 > /proc/nctuns_emud
int procfile_write(struct file* file, const char* buf, unsigned long count,
		   void* data)
{
	int i, head;
	unsigned long intip=0, extip=0;

	if(copy_from_user(procfs_buf, buf, count))
		return -EFAULT;

	// parsing
	i = 0;
	while(i < count)
	{
		head = i;
                // Find the first space or tab in this statement
		while(i<count && procfs_buf[i] != ' ' && procfs_buf[i] != '\t')
			++i;

		// Clear all rule
		if(!strncmp(&procfs_buf[head], "clear", 5))
		{
			iptab_count = 0;
			routerIF_count = 0;
			++i;
		}
	
		// Insert an external host data
		else if(!strncmp(&procfs_buf[head], "host", 4))
		{
			// Get the external ip of the host.
			++i;
			head = i;
			while(i < count && procfs_buf[i] != ' ' && procfs_buf[i] != '\t')
				++i;
			procfs_buf[i] = '\0';
			extip = in_aton(&procfs_buf[head]);

			// Get the internal ip of the host.
			++i;
			head = i;
			while(i < count && procfs_buf[i] != ' ' && procfs_buf[i] != 0 
                                   && procfs_buf[i] != '\n' && procfs_buf[i] != '\t')
				++i;

			procfs_buf[i] = '\0';
			intip = in_aton(&procfs_buf[head]);
			--i;

			if(intip && extip)
			{
				// Write into the binding table
				iptab[iptab_count].extIP = extip;
				iptab[iptab_count].intIP = intip;
				++iptab_count;
			}
		}

		// Insert an external router data
		else if(!strncmp(&procfs_buf[head], "router", 6))
		{
			// Get the real interface IP address.
			++i;
			head = i;
			while(i < count && procfs_buf[i] != ' ' && procfs_buf[i] != '\t')
				++i;
			procfs_buf[i] = '\0';
			extip = in_aton(&procfs_buf[head]);

			// Get the internal interface IP address.
			++i;
			head = i;
			while(i < count && procfs_buf[i] != ' ' && procfs_buf[i] != 0 
                                   && procfs_buf[i] != '\n' && procfs_buf[i] != '\t')
				++i;

			procfs_buf[i] = '\0';
			intip = in_aton(&procfs_buf[head]);
			--i;

			if(intip && extip)
			{
				// Write into the binding table
				routerIF[routerIF_count].extIP = extip;
				routerIF[routerIF_count].intIP = intip;
				++routerIF_count;
			}
		}
		// Find the next statement
		while(i < count && procfs_buf[i] != '\n')
			++i;
		while(i < count && procfs_buf[i] == '\n')
			++i;
	}

	return count;
}

// module initialization
int init_module()
{
	// create procfs such that user can use commandline to
	// communicate with this module
	emud_proc_file = create_proc_entry(PROCFS_NAME, 0644, NULL);
	if(!emud_proc_file)
	{
		remove_proc_entry(PROCFS_NAME, NULL);
		printk(KERN_ALERT "Error: The proc file /proc/%s of NCTUns Emulation Daemon could not initialize\n", PROCFS_NAME);
		return -ENOMEM;
	}

	emud_proc_file->read_proc = procfile_read;
	emud_proc_file->write_proc = procfile_write;
	emud_proc_file->owner = THIS_MODULE;
	emud_proc_file->mode = S_IFREG | S_IRUGO;
	emud_proc_file->uid = 0;
	emud_proc_file->gid = 0;
	emud_proc_file->size = 50;

	// Setup hook in netfilter such that packet processed by ip_recv
	// will be processed by this module first.
	nfho.hook = IP_Recv_Hook;
	nfho.owner = THIS_MODULE;
	nfho.pf = PF_INET;
	nfho.hooknum = 0;
	nfho.priority = NF_IP_PRI_FIRST;
	nf_register_hook(&nfho);

	// initial the binding table
	memset(iptab, 0, sizeof iptab);
	memset(routerIF, 0, sizeof routerIF);
	iptab_count = 0;
	routerIF_count = 0;

	// Make the check in fib_frontend.c passed
	nctuns_emu_module = 1;

	return 0;
}

void cleanup_module()
{
	// release the hook
	nf_unregister_hook(&nfho);

	// release socket and procfs
	remove_proc_entry(PROCFS_NAME, NULL);

	// for fib_frontend.c
	nctuns_emu_module = 0;
}

MODULE_LICENSE("GPL");
