#include <linux/module.h>
#include <linux/pid.h>
#include <linux/types.h>
#include <nctuns/nctuns_kernel.h>

/* ===================================================================== *
 * the following global variable will be used for internal nctuns kernel *
 * ===================================================================== */

/* keep the process ID of NCTUns engine in the specified variable */
pid_t nctuns = -1;

/* the scale of nctuns tick, this value can be set by syscall */
uint32_t microscale = 10;

EXPORT_SYMBOL(nctuns);
EXPORT_SYMBOL(microscale);

/*
 * the tun_struct pointer will be used to detect the specified nctuns_tun
 * whether alive.
 */
struct tun_struct;

struct tun_struct 	*tunctl[MAX_NUM_TUN];
struct tun_struct 	*tunctl_ec;

EXPORT_SYMBOL(tunctl);
EXPORT_SYMBOL(tunctl_ec);

/* ===================================================================== *
 * the following global variable will be used for memory mapping.        *
 * ===================================================================== */

/*
 * The virtual clock of nodes. In the current version, we use only node 0's
 * clock as the whole simulation system's clock.
 */
//u64		NCTUNS_nodeVC[2] = {100llu, 0};

/*
 * the current nctuns and event tunnel queue length, the NCTUns engine just
 * read only
 */
//uint32_t 	tunif_qlen[MAX_NUM_TUN];
//uint32_t 	ce_tun_qlen;

/*
 * the current fifo queue length and max queue length of NCTUns engine, the
 * kernel just read only
 */
//uint32_t 	fifoIFmaxqlen[MAX_NUM_TUN];
//uint32_t 	fifoIFcurqlen[MAX_NUM_TUN];

//EXPORT_SYMBOL(NCTUNS_nodeVC);
//EXPORT_SYMBOL(tunif_qlen);
//EXPORT_SYMBOL(ce_tun_qlen);
//EXPORT_SYMBOL(fifoIFmaxqlen);
//EXPORT_SYMBOL(fifoIFcurqlen);
