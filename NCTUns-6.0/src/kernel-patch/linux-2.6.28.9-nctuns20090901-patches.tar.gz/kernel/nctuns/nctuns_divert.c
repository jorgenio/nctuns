#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/vmalloc.h>
#include <linux/types.h>
#include <linux/socket.h>
#include <linux/netdevice.h>
#include <linux/netfilter_ipv4.h>
#include <linux/list.h>
#include <net/sock.h>
#include <linux/ip.h>
#include <linux/in.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/icmp.h>

#include <nctuns/nctuns_kernel.h>
#include <nctuns/nctuns_ticks.h>
#include <nctuns/nctuns_divert.h>

//ystseng:2006/04/29 add
struct list_head rule_table[NF_INET_NUMHOOKS];

/*
 *  clean all divert entry of all hooks list
 */
static void nctuns_clean_divert_entry(void)
{
	int 			i = 0;
	struct list_head 	*curr, *tmp;
	struct divert_entry	*dentry;
	
	for (i = 0; i < NF_INET_NUMHOOKS; i++) {
		list_for_each_safe(curr, tmp, &rule_table[i]) {
			dentry = list_entry(curr, struct divert_entry, entry);

			list_del(curr);
			kfree(dentry);
		}
	}

	return;
}

/*
 * find the same divert_rule of divert_entry in rule_table of the specified hook
 */
static struct divert_entry *nctuns_divert_match(u_long hook, struct divert_rule *rule)
{
	struct list_head 	*curr;
	struct divert_entry	*entry;
	
	list_for_each(curr, &rule_table[hook]) {
		entry = list_entry(curr, struct divert_entry, entry);
		
		if (memcmp(rule, entry, sizeof(struct divert_rule)) == 0)
			return entry;
	}
	
	return NULL;
}

/*
 * find the matching divert_rule of divert_entry for the specified skb
 */
static struct divert_entry *nctuns_pkt_match(int hook, struct sk_buff *skb)
{
	struct list_head 	*curr;
	struct divert_entry	*dentry;
	struct divert_rule 	*dr;
	struct iphdr 		*ip;
	struct tcphdr		*tcphdr;
	struct udphdr		*udphdr;

	ip = ip_hdr(skb);

	list_for_each(curr, &rule_table[hook]) {
		dentry = list_entry(curr, struct divert_entry, entry);
		dr = divert_rl(dentry);

		/*
		 * if the protocol is not IP protocol and the ip->protocol is
		 * not the same with rule, then go to find next rule
		 */
		if (dr->proto != IPPROTO_IP && dr->proto != ip->protocol)
			continue;

		if (dr->srcip)
			if ((dr->srcip & dr->smask) != (ip->saddr & dr->smask))
				continue;

		if (dr->dstip)
			if ((dr->dstip & dr->dmask) != (ip->daddr & dr->dmask))
				continue;
		
		/*
		 * if this rule is matching for IP protocol, then return the
		 * rule_entry, otherwise, continue to match protocol and port
		 */
		if (dr->proto == IPPROTO_IP)
			return dentry;
		
		if (ip->protocol == IPPROTO_TCP) {
			tcphdr = (struct tcphdr*)((char*)ip + (ip->ihl << 2));

			if (dr->sport)
				if(dr->sport != tcphdr->source)
					continue;

			if (dr->dport)
				if(dr->dport != tcphdr->dest)
					continue;

			return dentry;
		}
		else if (ip->protocol == IPPROTO_UDP) {
			udphdr = (struct udphdr*)((char*)ip + (ip->ihl << 2));

			if (dr->sport)
				if(dr->sport != udphdr->source)
					continue;

			if (dr->dport)
				if(dr->dport != udphdr->dest)
					continue;

			return dentry;
		}
		else if (ip->protocol == IPPROTO_ICMP)
			return dentry;
	}
	return NULL;
}

/*
 * hook function which be called by netfilter subsystem
 */
unsigned int divert_hook(unsigned int hook, 
		           struct sk_buff *pskb, 
			   const struct net_device *indev, 
			   const struct net_device *outdev, 
			   int (*okfn)(struct sk_buff *))
{
	struct divert_entry *dentry;
	struct divert_rule	*dr;

	if ((dentry = nctuns_pkt_match(hook, pskb))) {
		dr = divert_rl(dentry);

		if (!dentry->sk) {
			Nprintk_err("Fatal error! Can not find the sock!!\n");
			return NF_ACCEPT;
		}

		/*
		 * record pkt input device
		 */
		if (indev) {
			pskb->dev = (struct net_device *)indev; 
		} else {
			/*
			 * XXX:
			 * Input device is NULL.
			 * This packet may be a LOCAL_OUT packet and it may 
			 * belong to someone socket. So, we should release
			 * the write socket buffer before divert it.
			 */
			if (pskb->destructor) {
				pskb->destructor(pskb);
				pskb->destructor = NULL;
			}
		}

		/*
		 * This pkt is a divert pkt.
		 */
		pskb->pkt_type = PACKET_DIVERT;

		if (sock_queue_rcv_skb(dentry->sk, pskb) < 0) {
			kfree_skb(pskb);
			Nprintk_err("now %lu, Enqueue fail!!\n", NCTUNS_ticks);
			return NF_ACCEPT;
		}

		return NF_STOLEN;
	}

	return NF_ACCEPT;
}

int nctuns_reg_divert_rule(enum divert_action_enum action, struct sock *sk, u_long hook, struct divert_rule __user *user_dr, int addr_len)
{
	struct list_head 	*curr;
	struct divert_entry	*dentry;
	struct divert_rule	*dr;

	struct divert_entry	tmp_rule;
	struct divert_rule	*tmp_dr;
	int			i, ret;

	tmp_rule.hook = hook;
	tmp_dr = divert_rl(&tmp_rule);

	if (user_dr) {
		ret = copy_from_user(tmp_dr, user_dr,
				min_t(int, addr_len, sizeof(struct divert_rule)));

		if (!sk || ret < 0 || tmp_dr->proto < 0)
			return ret;

		tmp_rule.sk = sk;
	}
	
	switch (action) {
	case syscall_NSC_divert_INFO:
		Nprintk_info("**** NCTUns divert rule table info : hook %lu ****\n", hook);
		if (list_empty(&rule_table[hook])) {
			printk("    hook %lu is empty!\n", hook);
			break;
		}

		i = 1;
		list_for_each(curr, &rule_table[hook]) {
			dentry = list_entry(curr, struct divert_entry, entry);
			dr = divert_rl(dentry);

			Nprintk_info("no. %d\n", i++);
			Nprintk_info("    sock = %p, proto = %d\n", dentry->sk, dr->proto);
			
			Nprintk_info("    srcip = " NIPQUAD_FMT ", netmask = " NIPQUAD_FMT " \n",
					NIPQUAD(dr->srcip), NIPQUAD(dr->smask));

			Nprintk_info("    dstip = " NIPQUAD_FMT ", netmask = " NIPQUAD_FMT " \n",
					NIPQUAD(dr->dstip), NIPQUAD(dr->dmask));

			Nprintk_info("    sport = %u, dport = %u\n",
					ntohs(dr->sport), ntohs(dr->dport));
		}

		break;

	case syscall_NSC_divert_FLUSH:
		nctuns_clean_divert_entry();
		break;

	case syscall_NSC_divert_ADDHEAD:
	case syscall_NSC_divert_ADDTAIL:
		dentry = (struct divert_entry *)
			kmalloc(sizeof(struct divert_entry), GFP_KERNEL);

		if (!dentry) {
			Nprintk_err("kernel memory request fails!\n");
			return -EIO;
		}

		memcpy(dentry, &tmp_rule, sizeof(struct divert_entry));

		inet_sk(sk)->hdrincl = 1;

		if (action == syscall_NSC_divert_ADDHEAD)
			list_add(&dentry->entry, &rule_table[hook]);
		else
			list_add_tail(&dentry->entry, &rule_table[hook]);

		break;
		
	case syscall_NSC_divert_DELETE:
		if ((dentry = nctuns_divert_match(hook, tmp_dr)) != NULL) {
			list_del(&dentry->entry);
			kfree(dentry);
		} else
			return -EBADR;
		break;

	case syscall_NSC_divert_MOVETAIL:
		if ((dentry = nctuns_divert_match(hook, tmp_dr)) != NULL) {
			list_move_tail(&dentry->entry, &rule_table[hook]);
		} else
			return -EBADR;
		break;

	default:
		return -EINVAL;
	}

	return (0);
}

EXPORT_SYMBOL(rule_table);
EXPORT_SYMBOL(divert_hook);
