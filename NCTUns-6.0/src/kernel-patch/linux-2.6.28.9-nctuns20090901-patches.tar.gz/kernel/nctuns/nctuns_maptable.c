#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>

#include <asm/uaccess.h>

#include <linux/netdevice.h>
#include <linux/inetdevice.h>
#include <linux/rcupdate.h>
#include <linux/tcp.h>

#include <net/tcp.h>
#include <net/udp.h>
#include <net/udplite.h>
#include <net/net_namespace.h>

#include <nctuns/nctuns_maptable.h>
#include <nctuns/nctuns_kernel.h>
#include <nctuns/nctuns_tun.h>

#define shift_offset(type)	((sizeof(type) >> 1) + 3)
#define shift_size(type)	((sizeof(type)) << 3)
#define round_bit(num, type)	(((num) >> shift_offset(type)) + \
	(((((num) & (shift_size(type) - 1)) + (shift_size(type) - 1)) & \
	~(shift_size(type) - 1)) >> shift_offset(type)))

struct MTable {
	unsigned long		totalNode;
	struct list_head	node_info;
	unsigned long		tunmap[round_bit(MAX_NUM_TUN, unsigned long)];
} mtable = {
	.totalNode = 0,
	.node_info = LIST_HEAD_INIT(mtable.node_info)
};

/*
 * initialize all port mapping table
 */
int mt_init(void)
{
	mt_free();

	rcu_read_lock();
	INIT_LIST_HEAD(&mtable.node_info);
	memset(&mtable.tunmap, 0, sizeof(mtable.tunmap));
	mtable.totalNode = 0;
	rcu_read_unlock();

	return (0);
}

/*
 * free all information for port mapping table
 */
int mt_free(void)
{
	struct list_head	*curr, *tmp_curr;
	struct hlist_node	*node, *tmp_node;
	struct hlist_node	*sknode, *tmp_sknode;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;
	struct pmap_info	*pmapinfo;
	struct sock		*sk;
	
	/* empty list */
	if (list_empty(&mtable.node_info))
		return (0);

	rcu_read_lock();
	/* otherwise, we free mapping table */
	list_for_each_safe(curr, tmp_curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		list_del(curr);

		/* free all interface information */
		hlist_for_each_safe(node, tmp_node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);

			hlist_del(node);
			kfree(ifinfo);
		}

		/* free all port mapping information */
		hlist_for_each_safe(node, tmp_node, &ninfo->pmap_info) {
			pmapinfo = hlist_entry(node, struct pmap_info, entry);

			hlist_del(node);
			hlist_for_each_safe(sknode, tmp_sknode, &pmapinfo->owner) {
				sk = hlist_entry(sknode, struct sock, nctuns_sock.pmap_list);

				/*
				 * if this sock struct didn't be free during
				 * previous simulation, then close it
				 */
				if (sk) {
					hlist_del_init(sknode);
					sk->nctuns_sock.pmap = NULL;

					Nprintk_info("Now to free a sock struct left from the previous simulation.\n");

					/*
					 * if this sock is tcp sock, then it
					 * may be not finished all close
					 * procedure, we must reset this sock
					 * and close it
					 * if we don't do it, conntrack of
					 * iptables will block the next syn
					 * packet so that delay the connection
					 * time
					 */
					if (sk->sk_prot == &tcp_prot) {
						/*
						 * reset peer socket
						 */
						tcp_send_active_reset(sk, GFP_KERNEL);
						tcp_done(sk);
					}
				}
			}
			kfree(pmapinfo);
		}
		kfree(ninfo);
	}
	rcu_read_unlock();
	
	return (0);
}

/*
 * copy	user-level engine maptable information to kernel
 * nid		=> Node ID
 * tid		=> Tun ID
 * *mac		=> Mac
 * s_port	=> port
 */
int mt_add(unsigned long nid, unsigned long tid, __u8 *mac, __u16 s_port)
{
	struct list_head	*curr;
	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	struct net_device	*dev;
	struct in_device	*in_dev;
	struct in_ifaddr	*ifa;
	unsigned long *bitmap;
	char str[10], myflags = 0;

	if (nid > MAX_NUM_NODE || tid > MAX_NUM_IF_TUN || nid == 0 || tid == 0)
		goto fail_out;

        /* check to see duplicated tunnel ID */
	bitmap = &mtable.tunmap[(tid - 1) >> shift_offset(unsigned long)];

	if ((*bitmap << ((tid - 1) & (shift_size(unsigned long) - 1))) & 0x80000000) {
		/* duplicated tunnel ID exists */
		Nprintk_err("tun ID %lu is duplicated with existed ID!!\n", tid);
		goto fail_out;
	}

	/* mark bitmap which be mapping to tunnel ID */
	*bitmap |= 0x80000000 >> ((tid - 1) & (shift_size(unsigned long) - 1));

	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid) {
			myflags = 1;
			break;
		}
	}

        /*
	 * if can not match node id, we should create
         * an entry to mapping table
	 */
	if (!myflags) {
		if (!(ninfo = (struct node_info *)
			kmalloc(sizeof(struct node_info), GFP_KERNEL))) {

			goto fail_out;
		}

		/* fill node information */
		ninfo->nodeID = nid;
		ninfo->numif = 0;
		ninfo->s_port = s_port;
		ninfo->lastport = s_port - 1;
		INIT_HLIST_HEAD(&ninfo->if_info);
		INIT_HLIST_HEAD(&ninfo->pmap_info);
		mtable.totalNode++;

		rcu_read_lock();
		list_add(&ninfo->entry, &mtable.node_info);
		rcu_read_unlock();
	}

	/* otherwise, create an entry */
	if (!(ifinfo = (struct if_info *)
		kmalloc(sizeof(struct if_info), GFP_KERNEL))) {

		kfree(ninfo);
		goto fail_out;
	}

	/* fill interfaces information */
	ifinfo->tunid = tid;
	ifinfo->tunip = 0;
	ifinfo->ifa = NULL;
	if (mac)
		memcpy(ifinfo->mac, mac, 6);
	
	/* find interface address */
        sprintf(str, "tun%lu", tid);

	dev = dev_get_by_name(&init_net, str);
	
	if (!dev) {
		Nprintk_err("Cannot find the device of %s!!\n", str);
		goto fail_out;
	}
	else if (is_nctuns_tun_dev(dev)) {
		in_dev = in_dev_get(dev);
		if (in_dev == NULL || (ifa = in_dev->ifa_list) == NULL) {
			Nprintk_err("Cannot find interface IP address of %s!!\n", str);
			kfree(ninfo);
			kfree(ifinfo);

			if (in_dev)
				in_dev_put(in_dev);

			dev_put(dev);
			goto fail_out;
		}
		in_dev_put(in_dev);

		if (mac)
			memcpy(dev->dev_addr, mac, dev->addr_len);
		dev_put(dev);

		//ystseng: 2006/12/11 adaptation
		ifinfo->ifa = ifa;
		ifinfo->tunip = ifa->ifa_local;
	}

	rcu_read_lock();
	hlist_add_head(&ifinfo->entry, &ninfo->if_info);
	ninfo->numif++;
	rcu_read_unlock();

	return (0);
fail_out:
	return (-EIO);
}

/*
 * get all interface ip address depend on node id
 * nid		=> Node ID
 * len		=> buffer length
 * *ipbuf	=> buffer pointer
 */
int mt_nidifinfo(unsigned long nid, int len, char *ipbuf)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	int 			i;
	char 			*adr, *cip;
	long			ret;

	if (nid > MAX_NUM_NODE || nid == 0)
		return (-EBADR);

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid) {
			adr = ipbuf;
			i = 0;
			/*
			 * string cat all ip of all interface information into
			 * user memory
			 */
			hlist_for_each(node, &ninfo->if_info) {
				if (adr + sizeof(__u32) - ipbuf > len)
					break;

				ifinfo = hlist_entry(node, struct if_info, entry);
				cip = (char *)&ifinfo->tunip;
				ret = copy_to_user((void *)adr, (void *)cip, sizeof(__u32));
				adr += sizeof(__u32);
			}
			return (adr - ipbuf);
		}
	}

	return (-EBADF);
}

/*
 * find node id depend on tunnel id
 * tid	=> tunnel ID
 */
unsigned long mt_tidtonid(unsigned long tunid)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	if (tunid > MAX_NUM_IF_TUN || tunid == 0)
		return (0);

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		/*
		 * find if_info by tunnel ID
		 */
		hlist_for_each(node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);
			if (ifinfo->tunid == tunid)
				return (ninfo->nodeID);
		}
	}

	return (0);
}

/*
 * find node id depend on ip address
 * ip	=> ip address
 */
unsigned long mt_iptonid(__u32 ip)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	if (!ip)
		return (0);

	/*
	 * list all node_info of tables
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		/*
		 * find node ID by tunnel ip
		 */
		hlist_for_each(node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);

			if (!ifinfo->ifa)
				continue;

			/* check interface IP addr. */
			if(ifinfo->tunip == ip)
				return (ninfo->nodeID);
		}
	}

	return (0);
}

/*
 * find node id depend on ip address, it will check ifa_list whether have equal
 * ip address
 * ip	=> ip address
 * dev	=> skb->dev
 */
unsigned long mt_iptonid_by_ifa(__u32 ip, struct net_device *dev)
{
	unsigned long		nodeID;
	int 			tid;

	if (!ip || !dev)
		return (0);

	if ((nodeID = mt_iptonid(ip)) == 0) {
		/*
		 * Can not map ip to node ID!
		 * We still need to give it a chance to check
		 * if it is a broaccast addr.
		 */
		if (is_nctuns_tun_dev(dev)) {
			struct tun_struct *tun = netdev_priv(dev);

			if ((tid = tun->tid) == 0)
				Nprintk_err("Cannot find tun ID of %s!!\n", dev->name);
			return mt_tidtonid(tid);
		}
	}

	return nodeID;
}

/*
 * compare source and distination IP, if the two IP's interface are created at
 * the same host (the same nodeID), return the nodeID
 * src_ip	=> src_ip address
 * dst_ip	=> dst_ip address
 */
unsigned long mt_ipcmp_nid(__u32 src_ip, __u32 dst_ip)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	int check_limit;

	if (!src_ip || !dst_ip)
		return (0);

	check_limit = src_ip == dst_ip ? 1 : 2;

	/*
	 * list all node_info of tables
	 */
	list_for_each(curr, &mtable.node_info) {
		int check_cnt = check_limit;

		ninfo = list_entry(curr, struct node_info, entry);

		/*
		 * if src_ip and dst_ip is different, than the host must have
		 * more than two interfaces, it is just possible satified this
		 * condition.
		 */
		if (!(ninfo->numif >= check_cnt))
			return (0);

		/*
		 * find node ID by tunnel ip
		 */
		hlist_for_each(node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);

			if (!ifinfo->ifa)
				continue;

			/* check interface IP addr. */
			if (ifinfo->tunip == src_ip || ifinfo->tunip == dst_ip)
				check_cnt--;

			/*
			 * we found the host which have the two interface
			 */
			if (check_cnt == 0)
				return ninfo->nodeID;
		}

		/*
		 * we just found one of the interfaces
		 */
		if (check_cnt != check_limit)
			return (0);
	}
	return (0);
}

/*
 * find ip address depend on tunnel id
 * tid	=> tunnel id
 */
__u32 mt_tidtoip(unsigned long tid)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;

	if (tid > MAX_NUM_IF_TUN || tid == 0)
		return (0);

	/*
	 * list all node_info of tables
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		/*
		 * find tunnel ip by tunnel id
		 */
		hlist_for_each(node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);

			if (!ifinfo->ifa)
				continue;

			if (ifinfo->tunid == tid)
				return ifinfo->tunip;
		}
	}

	return (0);
}

/*
 * find ip address depend on node id and specified local ip
 * *mac	=> buffer
 * tid	=> tunnel id
 */
__u32 mt_randnidtoip(unsigned long nid, __u32 specified_local_ip)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;
	__u32			si;

	if (nid > MAX_NUM_NODE || nid == 0)
		return (0);

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid) {
			hlist_for_each(node, &ninfo->if_info) {
				ifinfo = hlist_entry(node, struct if_info, entry);

				if (!ifinfo->ifa)
					continue;

				si = ifinfo->tunip;

                                /*
				 * NCTUNS: C.C. Lin: if specified_local_ip is
				 * non-zero, it means that the user program has
				 * been chosen one of its local IP address as 
				 * the local address for this socket. And we
				 * should not return an IP address arbitrarily.
                                 */
				if (!specified_local_ip)
					return si;
				else {
					if (si == specified_local_ip)
						return si;
					else
						continue;
				}
			}

			/*
			 * cannot find any interface information in this node,
			 * break it.
			 */
			break;
		}
	}

	return (0);
}

/*
 * mapping virtual port to real port number
 * nid		=> node id
 * vport	=> virtual port number
 */
__u16 mt_VtoRport(unsigned long nid, struct proto *prot, __u32 ip, __u16 vport)
{
	struct list_head	*curr;
	struct hlist_node	*node, *sknode;

	struct node_info 	*ninfo = NULL;
	struct pmap_info   	*pmapinfo;
	struct sock		*sk;

	if (nid > MAX_NUM_NODE || nid == 0)
		return (0);

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid)
			break;
	}
	if (!ninfo || ninfo->nodeID != nid)
		return (0);//failure

	/*
	 * find real port by ip and virtual port
	 */
	rcu_read_lock();
	hlist_for_each(node, &ninfo->pmap_info) {
		pmapinfo = hlist_entry(node, struct pmap_info, entry);

		hlist_for_each(sknode, &pmapinfo->owner) {
			sk = hlist_entry(sknode, struct sock, nctuns_sock.pmap_list);

			if (pmapinfo->vport == vport &&
			    pmapinfo->prot == prot &&
			    (!inet_sk(sk)->rcv_saddr || 
			     inet_sk(sk)->rcv_saddr == ip)) {

				rcu_read_unlock();
				return pmapinfo->rport;
			}
		}
	}
	rcu_read_unlock();

	return (0);//failure
}

/*
 * mapping real port to virtual port number
 * prot		=> protocol pointer
 * rport	=> real port number
 */
__u16 mt_RtoVport(struct proto *prot, __u16 rport)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct pmap_info   	*pmapinfo;

	if (!prot || !rport)
		return (0);

	/*
	 * list all node_info of tables
	 */
	rcu_read_lock();
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		/*
		 * find virtual port by protocol and real port
		 */
		hlist_for_each(node, &ninfo->pmap_info) {
			pmapinfo = hlist_entry(node, struct pmap_info, entry);

			if (pmapinfo->prot == prot && pmapinfo->rport == rport) {
				rcu_read_unlock();
				return pmapinfo->vport;
			}
		}
	}
	rcu_read_unlock();
	return (0);
}

/*
 * create a new struct pmap to bind port for nctuns
 */
int mt_bind(struct sock *sk)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo = NULL;
	struct pmap_info   	*pmapinfo = NULL;
	struct inet_sock *inet, *inet2;
	struct sock *sk2;

	if (!is_nctuns_valid_sock(sk))
		return (1);//failure

	inet = inet_sk(sk);

	/*
	 * ystseng: 06/07/22 marked
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nctuns_sock_node_id(sk))
			goto node_found;
	}

	return (-EBADR);//failure
node_found:
	rcu_read_lock();
	hlist_for_each(node, &ninfo->pmap_info) {
		pmapinfo = hlist_entry(node, struct pmap_info, entry);

		if (pmapinfo->vport == inet->vsport && pmapinfo->prot == sk->sk_prot) {
			goto pmap_found;
		}
	}
	goto pmap_not_found;

pmap_found:
	hlist_for_each(node, &pmapinfo->owner) {
		sk2 = hlist_entry(node, struct sock, nctuns_sock.pmap_list);
		inet2 = inet_sk(sk2);

		/*
		 * Take new machanism to check whether it has be used by other
		 * socket.
		 */
		if (sk2 != sk &&
		    (!sk2->sk_bound_dev_if ||
		     !sk->sk_bound_dev_if ||
		     sk2->sk_bound_dev_if == sk->sk_bound_dev_if) &&
		    (!inet2->rcv_saddr ||
		     !inet->rcv_saddr ||
		     inet2->rcv_saddr == inet->rcv_saddr) &&
		    (!sk2->sk_reuse || !sk->sk_reuse)) {

			rcu_read_unlock();
			return (-EBUSY);
		}
	}

pmap_not_found:
	rcu_read_unlock();
	if (!(pmapinfo = (struct pmap_info *)
		//kmalloc(sizeof(struct pmap_info), GFP_KERNEL))) {
		kmalloc(sizeof(struct pmap_info), GFP_ATOMIC))) {

		return (1);
	}
	pmapinfo->prot = sk->sk_prot;
	pmapinfo->rport = inet->num;
	pmapinfo->vport = inet->vsport;
	INIT_HLIST_HEAD(&pmapinfo->owner);

	rcu_read_lock();
	hlist_add_head(&pmapinfo->entry, &ninfo->pmap_info);

	sk->nctuns_sock.pmap = pmapinfo;
	hlist_add_head(&sk->nctuns_sock.pmap_list, &pmapinfo->owner);
	rcu_read_unlock();

	return (0);
}

/*
 * unbind port mapping information for nctuns
 */
int mt_unbind(struct sock *sk)
{
	if (!is_nctuns_valid_sock(sk))
		return (1);

	if (hlist_unhashed(&sk->nctuns_sock.pmap_list) || !sk->nctuns_sock.pmap)
		return (1);

	rcu_read_lock();
	hlist_del_init(&sk->nctuns_sock.pmap_list);

	/*
	 * if this port mapping information don't hook any sock, then free it
	 */
	if (hlist_empty(&sk->nctuns_sock.pmap->owner)) {
		hlist_del(&sk->nctuns_sock.pmap->entry);
		kfree(sk->nctuns_sock.pmap);
		sk->nctuns_sock.pmap = NULL;
	}
	rcu_read_unlock();

	return (0);
}

/*
 * lookup socket by virtual pointer in mtable listed list
 * sock		=> struct sock
 * vport	=> virtual port number
 */
static int mt_lookupDupVport(struct sock *sk, __u16 vport)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct pmap_info   	*pmapinfo;
	struct sock		*sk2;
	struct inet_sock	*inet, *inet2;

	if (!is_nctuns_valid_sock(sk))
		return (1);//failure

	inet = inet_sk(sk);

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nctuns_sock_node_id(sk)) {
			/*
			 * find map_info by virtual port at this node
			 */
			hlist_for_each(node, &ninfo->pmap_info) {
				pmapinfo = hlist_entry(node, struct pmap_info, entry);

				if (pmapinfo->vport == vport && pmapinfo->prot == sk->sk_prot)
					goto pmap_found;
			}
		}
	}
	goto pmap_not_found;

pmap_found:
	hlist_for_each(node, &pmapinfo->owner) {
		sk2 = hlist_entry(node, struct sock, nctuns_sock.pmap_list);
		inet2 = inet_sk(sk2);

		if (sk2 != sk &&
		    (!sk2->sk_bound_dev_if ||
		     !sk->sk_bound_dev_if ||
		     sk2->sk_bound_dev_if == sk->sk_bound_dev_if) &&
		    (!inet2->rcv_saddr ||
		     !inet->rcv_saddr ||
		     inet2->rcv_saddr == inet->rcv_saddr) &&
		    (!sk2->sk_reuse || !sk->sk_reuse)) {

			Nprintk_warning("Found duplicated vport %u of node ID %lu.\n",
				vport, nctuns_sock_node_id(sk));
			return (1);
		}
	}

pmap_not_found:
	return (0);
}

/*
 * find next unuse port at this node and return it
 * sk	=> struct sock
 */
__u16 mt_getunuseVport(struct sock *sk)
{
	struct list_head	*curr;
	struct node_info 	*ninfo = NULL;
	int count;

	if (!is_nctuns_valid_sock(sk))
		return (0);//failure

	/*
	 * find node_info by node ID
	 */
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nctuns_sock_node_id(sk))
			goto node_found;
			
	}
	return (0);

node_found:
	count = LAST_PORT - START_PORT;
	do {
		if (count-- < 0)
			return (0);//failure

		ninfo->lastport++;
		if (ninfo->lastport < START_PORT || ninfo->lastport > LAST_PORT)
			ninfo->lastport = START_PORT - 1;
		
	} while (mt_lookupDupVport(sk, ninfo->lastport));

	return (ninfo->lastport);
}

/*
 * find all tunnel id depend on nid
 * nid	=> node id
 * num	=> unsigned long buffer array length
 * buf	=> unsigned long buffer array pointer
 */
int mt_nidtotid(unsigned long nid, int num, unsigned long *buf)
{
	struct list_head	*curr;
	struct hlist_node	*node;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;
	unsigned long		*mybuf;
	int 			ret, cnt = 0;

	if (nid > MAX_NUM_NODE || nid == 0)
		return (-EBADR);

	if (!(mybuf = (unsigned long *)
		kmalloc(num * sizeof(unsigned long), GFP_KERNEL))) {

		return (-EIO);
	}

	memset(mybuf, 0, num * sizeof(unsigned long));

	list_for_each (curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid) {
			cnt = 0;
			hlist_for_each(node, &ninfo->if_info) {
				ifinfo = hlist_entry(node, struct if_info, entry);
				if (cnt >= num)
					break;

				mybuf[cnt++] = ifinfo->tunid;
			}
			ret = copy_to_user((void *)buf, (void *)mybuf, num * sizeof(unsigned long));
			break;
		}
	}

	kfree(mybuf);

	return (cnt);
}

/*
 * get total number of tid depend on nid
 * nid	=> node id
 */
unsigned long mt_tidnum(unsigned long nid)
{
	struct list_head	*curr;
	struct node_info 	*ninfo;

	if (nid > MAX_NUM_NODE || nid == 0)
		return (0);

	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry);

		if (ninfo->nodeID == nid)
			return ninfo->numif;
	}

	return (0);
}

/*
 * get tunnel id depend device name
 */
unsigned long mt_gettidbyname(char *name)
{
	if (strncmp(name, "tun", 3) != 0) {
		if (strncmp(name, EVENT_TUN_NAME, strlen(EVENT_TUN_NAME)) != 0)
			Nprintk_warning("Cannot find tun ID of %s.\n", name);
	}
	else {
		return simple_strtol(name + 3, NULL, 0);
	}

	return (0);
}

/*
 * find a useful virtual port for this socket
 */
int mt_get_port(struct sock *sk, unsigned short snum)
{
	if (!is_nctuns_valid_sock(sk))
		return (-EBADR);

	/*
	 * non-specified port number, then find one useful port for it
	 */
	if (snum != 0) {
		if (!mt_lookupDupVport(sk, snum))
			inet_sk(sk)->vsport = snum;
		else {
			Nprintk_err("Port %u of node ID %lu is already in use!!\n",
				snum, nctuns_sock_node_id(sk));
			return (-EADDRINUSE);
		}
	}
	else {
		inet_sk(sk)->vsport = mt_getunuseVport(sk);
		if (!inet_sk(sk)->vsport) {
			Nprintk_err("looking up for a unused Vport of node ID %lu fails!!\n",
				nctuns_sock_node_id(sk));
			return (-EADDRINUSE);
		}
	}

	return (0);
}

/*
 * show mapping table
 * nid	=> node id
 */
void mt_display(void)
{
	struct list_head	*curr;
	struct hlist_node	*node;
	struct hlist_node	*sknode;

	struct node_info 	*ninfo;
	struct if_info   	*ifinfo;
	struct pmap_info	*pmapinfo;
	struct in_ifaddr	*ifa;
	struct sock		*sk;
	struct inet_sock *inet;

	if (list_empty(&mtable.node_info)) {
		Nprintk_info("\n[mt_display]..mtable is empty..!!\n");
		return;
	}
	
	list_for_each(curr, &mtable.node_info) {
		ninfo = list_entry(curr, struct node_info, entry); 
		Nprintk_info("\nNode ID: %lu\n", ninfo->nodeID);
		Nprintk_info("  Number of interfaces: %d\n", ninfo->numif);
		Nprintk_info("  Start port: %u\n", ninfo->s_port);
		Nprintk_info("  Interface:\n");

		hlist_for_each(node, &ninfo->if_info) {
			ifinfo = hlist_entry(node, struct if_info, entry);

			Nprintk_info("    tun%lu:\n", ifinfo->tunid);

			if((ifa = ifinfo->ifa) == NULL)
				break;

			Nprintk_info("    inet " NIPQUAD_FMT, NIPQUAD(ifa->ifa_local));

			printk("  netmask " NIPQUAD_FMT "\n", NIPQUAD(ifa->ifa_mask));

			Nprintk_info("    broadcast " NIPQUAD_FMT, NIPQUAD(ifa->ifa_broadcast));

			printk("  ether %02x:%02x:%02x:%02x:%02x:%02x\n",
				ifinfo->mac[0], ifinfo->mac[1], ifinfo->mac[2],
				ifinfo->mac[3], ifinfo->mac[4], ifinfo->mac[5]);
		}

		Nprintk_info("\n  used ports:\n");
		hlist_for_each(node, &ninfo->pmap_info) {
			pmapinfo = hlist_entry(node, struct pmap_info, entry);

			Nprintk_info("    protocol: %s\n", pmapinfo->prot->name);
			/* used for test */
			hlist_for_each(sknode, &pmapinfo->owner) {
				sk = hlist_entry(sknode, struct sock, nctuns_sock.pmap_list);
				Nprintk_info("      the sock state = %d\n", sk->__sk_common.skc_state);

				/* local info. */
				inet = inet_sk(sk);
				Nprintk_info("      laddr: " NIPQUAD_FMT, NIPQUAD(inet->rcv_saddr));
				printk("  lport: (r, v)=>(%u, %u)\n",
						ntohs(inet->sport), inet->vsport);

				/* foreign info. */
				Nprintk_info("      faddr: " NIPQUAD_FMT, NIPQUAD(inet->daddr));
				printk("  fport: %u\n", ntohs(inet->dport));
			}
		}
	}

	return;
}

void mt_getipprefix(__u32 *postfix)
{
    	struct list_head 	*curr;
	struct hlist_node 	*node;

	struct node_info	*ninfo;
	struct if_info		*ifinfo;

	/*
	 * list all node_info of tables
	 */
	list_for_each(curr , &mtable.node_info) {
	    	ninfo = list_entry(curr , struct node_info , entry);

		/*
		 * find complete ip address by postfix
		 */
		hlist_for_each(node , &ninfo->if_info) {
		    	ifinfo = hlist_entry(node , struct if_info , entry);

			if(!ifinfo->ifa)
			    continue;

			if( (ifinfo->tunip&0xFFFF0000) == (*postfix) ) {
			    (*postfix) = ifinfo->tunip;
			    return;
			}
			else if( ((ifinfo->tunip&0xFFFF0000)|0xFF000000) == (*postfix)) {
			    (*postfix) = (ifinfo->tunip | 0xFF000000);
			    return;
			}
		}
	}
}    

EXPORT_SYMBOL(mt_iptonid);
EXPORT_SYMBOL(mt_ipcmp_nid);
