#include <linux/kernel.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/inetdevice.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/if_tun.h>
#include <linux/list.h>

#include <net/sock.h>

#include <nctuns/nctuns_kernel.h>
#include <nctuns/nctuns_mmap.h>
#include <nctuns/nctuns_ticks.h>
#include <nctuns/nctuns_sched.h>
#include <nctuns/nctuns_sock.h>
#include <nctuns/nctuns_tun.h>
#include <nctuns/nctuns_callout.h>

/*
 * the instance of tunctl is in nctuns_mmap.c
 */
extern struct tun_struct 	*tunctl_ec;

/*
 * the callwheel variable is the timer linked list head, it keep all timers
 * which be mounted with nctuns engine
 */
struct callwheel 	callwheel;

int nctuns_callback(void)
{
	int cnt = 0;
	struct list_head 	*head, *curr, *tmp;
	struct timer_list	*timer;

	/* release NCTUns engine cpu time */
	set_current_state(TASK_INTERRUPTIBLE);

	head = callwheel.vec + ((NCTUNS_ticks_to_us) & callwheelmask); 

	/*
	 * list all timer in this linked list
	 */
	list_for_each_safe(curr, tmp, head) {
		timer = list_entry(curr, struct timer_list, entry);	
		
		/*
		 * timer->expires is mili-second 
		 */
		if (timer->expires == NCTUNS_ticks) {
			void (*fn)(unsigned long);
			unsigned long data;

			cnt++;
			fn = timer->function;
			data = timer->data;

			//ystseng: 06/07/10 adaptation
			del_singleshot_timer_sync(timer);

			fn(data);
			
			(callwheel.count)--;
		}
	}
	set_current_state(TASK_RUNNING);

	return cnt;
}


void nctuns_clear_callwheel(void)
{
	int 			i;
	
	/*
	 * Remove all callout left from the previous simulation case.
	 */
	for (i = 0; i < callwheelsize; i++)
		INIT_LIST_HEAD(callwheel.vec + i);

	callwheel.count = 0;

	return;
}

/*
 * add a tun_event to event tunnel
 */
int nctuns_add_tun_event(uint64_t *expires, int flag, pid_t pid, unsigned long nid, int socket_fd)
{
	struct tun_event	*tep;
	struct tun_struct 	*t0p = tunctl_ec;
	struct sk_buff		*t0skb;

	if (tunctl_ec == NULL)
		return (-1);

	/*
	 * add a tun0 event
	 */
	if (skb_queue_len(&t0p->readq) >= t0p->dev->tx_queue_len) {
		Nprintk_warning("tunctl_ec queue full, queue len = %d(%lu)\n",
				skb_queue_len(&t0p->readq), t0p->dev->tx_queue_len);
	} else {
		if(!(t0skb = alloc_skb(sizeof(struct tun_event), GFP_ATOMIC)))
		{
			t0p->dev->stats.rx_dropped++;
			return (-1);
		}
		tep = (struct tun_event *)t0skb->data;
		tep->pid   = pid;
		tep->nid   = nid;
		tep->flag  = flag;
		tep->socket_fd = socket_fd;

		
		if (*expires < ULLONG_MAX)
			tep->value = *expires;//micro-second
		else
			tep->value = *expires = ULLONG_MAX;
		
		/*
		 * Special situation:
		 * timeout interval is less than 1 ms
		 */
		if (tep->value == 0 || *expires <= NCTUNS_ticks_to_us)
			tep->value = *expires = (NCTUNS_ticks_to_us) + 1;

		/*
		 * Insert t0skb into tun0
		 */
 		t0skb->len = sizeof(struct tun_event) + 4;
		t0skb->dev = t0p->dev;

		skb_queue_tail(&t0p->readq, t0skb);
		(*ce_tun_qlen)++;
	}
	return (0);
}

/*
 * add a timer to nctuns timer_list, before enter this function, caller must
 * lock timer base first
 */
void nctuns_callout_helper(struct timer_list *timer, long us)
{
	struct list_head 	*vec;
	struct task_struct 	*nctuns_proc;
	uint64_t		expires = ((uint64_t)(timer->expires)*1000 + us);
	uint64_t		result;

	/*
	 * add a tun0 event
	 */
	if (nctuns_add_tun_event(&expires, T0E_TIMEOUT, current->tgid, current->nctuns_task.nodeID, 0) == -1)
		return;

	result = expires;
	do_div(result, 1000);
	timer->expires = (unsigned long)result;
	
	/*
	 * Insert timer into callwheel
	 */

	vec = callwheel.vec + (expires & callwheelmask);
	list_add(&timer->entry, vec);
	(callwheel.count)++;

	nctuns_proc = find_task_by_pid_ns(nctuns, &init_pid_ns);
	if(nctuns_proc != NULL)
		wake_up_process(nctuns_proc);

	return ;
}

extern void tcp_write_timer(unsigned long);
extern void tcp_delack_timer(unsigned long);
extern void tcp_keepalive_timer(unsigned long);
extern long hrtimer_nanosleep_restart(struct restart_block *restart);
extern int hrtimer_wakeup(struct hrtimer *timer);
extern void process_timeout(unsigned long __data);

int check_if_nctuns_timer(struct timer_list *timer)
{
	void (*fn)(unsigned long);

	fn = timer->function;

	if (fn == tcp_write_timer || fn == tcp_delack_timer ||
		fn == tcp_keepalive_timer) {

		struct sock *sk = (struct sock *)timer->data;

		if (is_nctuns_sock(sk))
			return nctuns_sock_node_id(sk);
	}

	//ystseng: 06/04/27 adaptation
	if (fn == (void *)(unsigned long)it_real_fn ||
		fn == (void *)(unsigned long)process_timeout||
		fn == (void *)(unsigned long)hrtimer_nanosleep_restart ||
		fn == (void *)(unsigned long)hrtimer_wakeup) {

		struct task_struct *p = (struct task_struct *)timer->data;

		if(is_nctuns_task(p))
			return nctuns_task_node_id(p);
	}
	
	return (0);
}
