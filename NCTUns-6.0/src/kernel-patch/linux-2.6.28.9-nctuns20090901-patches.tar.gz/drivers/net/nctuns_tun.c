/*
 *  NCTUns TUN - NCTUns TUN device driver.
 *  Copyright (C) 2007-2009 Yan-Shiun Tzeng <ystseng@csie.nctu.edu.tw>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 */

/*
 *  Changes:
 *
 *  Yan-Shiun Tzeng <ystseng@csie.nctu.edu.tw> 2007/03/09
 *    Split this driver from TUN device driver, and called "nctuns_tun"
 *    We re-writted tun_init, tun_cleanup function to support the sysfs
 *    subsystem, let udev detection mechanism create char device node at
 *    /dev. It can find the device information in /sysfs/class/nctuns (this
 *    class is created by this driver).
 *
 *    tun_net_xmit, tun_net_init, tun_get_user, tun_chr_aio_read, tun_set_iff,
 *    tun_chr_ioctl, and tun_get_drvinfo are modified to support NCTUns
 *    simulator, esepcially, tun_net_xmit and tun_get_user are important
 *    function for this driver. Previously, we hacked tun device driver and
 *    destroyed the original mechanism, so that users can't use the function
 *    which need tunnel device supported. Now, this driver is independence from
 *    tun device driver, but it still use the data struct of tun.
 */

#define DRV_NAME	"nctuns_tun"
#define DRV_VERSION	"1.0"
#define DRV_DESCRIPTION	"NCTUns TUN device driver"
#define DRV_COPYRIGHT	"(C) 2006-2008 Yan-Shiun Tzeng<ystseng@csie.nctu.edu.tw>"

#include <linux/module.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/smp_lock.h>
#include <linux/poll.h>
#include <linux/fcntl.h>
#include <linux/init.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/ethtool.h>
#include <linux/rtnetlink.h>
#include <linux/if.h>
#include <linux/if_arp.h>
#include <linux/if_ether.h>
#include <linux/if_tun.h>
#include <linux/crc32.h>
#include <linux/cdev.h>
#include <linux/nsproxy.h>
#include <linux/virtio_net.h>
#include <net/net_namespace.h>
#include <net/netns/generic.h>

#include <linux/ip.h>
#include <linux/netfilter_ipv4.h>

#include <nctuns/nctuns_kernel.h>
#include <nctuns/nctuns_mmap.h>
#include <nctuns/nctuns_ticks.h>
#include <nctuns/nctuns_sched.h>
#include <nctuns/nctuns_ssdd.h>
#include <nctuns/nctuns_tun.h>
#include <nctuns/nctuns_maptable.h>
#include <net/route.h>

#define MAX_NCTUNS_TUN_MIXORS	10

#ifdef TUN_DEBUG
static int debug;
#endif

extern struct tun_struct 	*tunctl[MAX_NUM_TUN];
extern struct tun_struct 	*tunctl_ec;

extern struct list_head 	rule_table[]; /* for divert packet */
extern void nctuns_packet_rcv(struct sk_buff *skb, struct net_device *dev);

/* TAP filterting */
static void addr_hash_set(u32 *mask, const u8 *addr)
{
	int n = ether_crc(ETH_ALEN, addr) >> 26;
	mask[n >> 5] |= (1 << (n & 31));
}

static unsigned int addr_hash_test(const u32 *mask, const u8 *addr)
{
	int n = ether_crc(ETH_ALEN, addr) >> 26;
	return mask[n >> 5] & (1 << (n & 31));
}

static int update_filter(struct tap_filter *filter, void __user *arg)
{
	struct { u8 u[ETH_ALEN]; } *addr;
	struct tun_filter uf;
	int err, alen, n, nexact;

	if (copy_from_user(&uf, arg, sizeof(uf)))
		return -EFAULT;

	if (!uf.count) {
		/* Disabled */
		filter->count = 0;
		return 0;
	}

	alen = ETH_ALEN * uf.count;
	addr = kmalloc(alen, GFP_KERNEL);
	if (!addr)
		return -ENOMEM;

	if (copy_from_user(addr, arg + sizeof(uf), alen)) {
		err = -EFAULT;
		goto done;
	}

	/* The filter is updated without holding any locks. Which is
	 * perfectly safe. We disable it first and in the worst
	 * case we'll accept a few undesired packets. */
	filter->count = 0;
	wmb();

	/* Use first set of addresses as an exact filter */
	for (n = 0; n < uf.count && n < FLT_EXACT_COUNT; n++)
		memcpy(filter->addr[n], addr[n].u, ETH_ALEN);

	nexact = n;

	/* Remaining multicast addresses are hashed,
	 * unicast will leave the filter disabled. */
	memset(filter->mask, 0, sizeof(filter->mask));
	for (; n < uf.count; n++) {
		if (!is_multicast_ether_addr(addr[n].u)) {
			err = 0; /* no filter */
			goto done;
		}
		addr_hash_set(filter->mask, addr[n].u);
	}

	/* For ALLMULTI just set the mask to all ones.
	 * This overrides the mask populated above. */
	if ((uf.flags & TUN_FLT_ALLMULTI))
		memset(filter->mask, ~0, sizeof(filter->mask));

	/* Now enable the filter */
	wmb();
	filter->count = nexact;

	/* Return the number of exact filters */
	err = nexact;

done:
	kfree(addr);
	return err;
}

/* Returns: 0 - drop, !=0 - accept */
static int run_filter(struct tap_filter *filter, const struct sk_buff *skb)
{
	/* Cannot use eth_hdr(skb) here because skb_mac_hdr() is incorrect
	 * at this point. */
	struct ethhdr *eh = (struct ethhdr *) skb->data;
	int i;

	/* Exact match */
	for (i = 0; i < filter->count; i++)
		if (!compare_ether_addr(eh->h_dest, filter->addr[i]))
			return 1;

	/* Inexact match (multicast only) */
	if (is_multicast_ether_addr(eh->h_dest))
		return addr_hash_test(filter->mask, eh->h_dest);

	return 0;
}

/*
 * Checks whether the packet is accepted or not.
 * Returns: 0 - drop, !=0 - accept
 */
static int check_filter(struct tap_filter *filter, const struct sk_buff *skb)
{
	if (!filter->count)
		return 1;

	return run_filter(filter, skb);
}

/* Network device part of the driver */

static unsigned int tun_net_id;
struct tun_net {
	struct list_head dev_list;
};

static const struct ethtool_ops tun_ethtool_ops;

/* Net device open. */
static int tun_net_open(struct net_device *dev)
{
	netif_start_queue(dev);
	return 0;
}

/* Net device close. */
static int tun_net_close(struct net_device *dev)
{
	netif_stop_queue(dev);
	return 0;
}

/* Net device start xmit for loopback */
static __inline__ int tun_net_loopback(struct sk_buff *skb, struct net_device *dev)
{
	struct iphdr *ip = ip_hdr(skb);

	/*
	 * src_nid is equal dst_nid, that's meaning this packet
	 * sent to itself.
	 */
	if (mt_ipcmp_nid(ip->saddr, ip->daddr)) {
		/*
		 * because of the socket table records S.S.D.D
		 * scheme for destination IP, so we need
		 * convert to S.S.D.D scheme so that it can
		 * lookup the receiver socket
		 */
		ip->saddr = nctuns_convert_ip_to_ssdd(ip->daddr, ip->saddr);

		/*
		 * Take care this !!
		 */
		skb_orphan(skb);
		dst_release(skb->dst);
		skb->dst = NULL;

		skb->protocol = __constant_htons(ETH_P_IP);
		skb->dev = dev;
		skb->ip_summed = CHECKSUM_UNNECESSARY;

		dev->trans_start = NCTUNS_ticks;
		dev->last_rx = NCTUNS_ticks;

		dev->stats.tx_packets++;
		dev->stats.rx_packets++;
		dev->stats.tx_bytes += skb->len;
		dev->stats.rx_bytes += skb->len;

		netif_rx_ni(skb);
		return (1);
	}
	return (0);
}

static __inline__ int tun_net_drop(struct sk_buff *skb, struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);

	/*
	 * if packet data will push to user space, then it will through this
	 * function, those variables are used by following code for NCTUns.
	 */
	struct tun_struct *t0p = tunctl_ec;

	/* Drop packet if interface is not attached */
	if (!tun->attached)
		goto drop;

	/* Packet dropping */

	/*
	 * XXX:
	 * Now, the nctuns_tun just supports IPv4, well, we will drop the
	 * packet when we found this packet is not IPv4 packet
	 */
	if (skb->protocol != __constant_htons(ETH_P_IP))
		goto drop;

	/*
	 * if the event tunnel is not ready or nctuns engine is not running,
	 * drop it
	 */
	if (t0p == NULL || t0p->dev == NULL || !is_nctuns_engine_in_task_queue())
		goto drop;

	/*
	 * the event tunnel is just for sending timeout event to NCTUns engine,
	 * it shouldn't be sent any packet from this tunnel
	 */
	if (tun == t0p) {
		Nprintk_warning("CurTick %lu (ms),", NCTUNS_ticks);
		Nprintk_warning("Drop in tun_net_xmit(), " EVENT_TUN_NAME ", due to a full queue\n");
		Nprintk_warning("    queue = %d, max = %lu\n", skb_queue_len(&t0p->readq), t0p->dev->tx_queue_len);
		goto drop;
	}

	/*
	 * queue is full, drop it
	 */
	if (skb_queue_len(&tun->readq) >= dev->tx_queue_len)
		goto drop;

	/*
	 * get the tunnel ID of this tunnel
	 *
	 * the FIFO module of NCTUns engine will affect the queue length
	 * computating, we need consider it.
	 */
	if (tun->tid <= MAX_NUM_IF_TUN && fifoIFcurqlen[tun->tid] + skb_queue_len(&tun->readq) >= fifoIFmaxqlen[tun->tid])
		goto drop;

	return 0;
drop:
	return -1;
}

/* Net device start xmit */
static int tun_net_xmit(struct sk_buff *skb, struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);

	/*
	 * if packet data will push to user space, then it will through this
	 * function, those variables are used by following code for NCTUns.
	 */
	struct tun_struct *t0p = tunctl_ec;
	struct iphdr *ip;
	struct ethhdr *eh;
	__u32 gt;

	DBG(KERN_INFO "%s: %s %d\n", tun->dev->name, __func__, skb->len);

	/* Packet dropping */
	if (tun_net_drop(skb, dev))
		goto drop;

	ip = ip_hdr(skb);

	/*
	 * recovery the ip header of packet, let user-level just see 1.0.x.x
	 * scheme, not S.S.D.D, Here, the source IP will be D.D.S.S from the
	 * point of source's view, in other words, the source IP scheme will be
	 * S.S.D.D from the point of destination's view. Therefore, we use
	 * nctuns_convert_ssdd_to_dst() to recovery the source ip (we need the
	 * last two bytes).
	 */
	nctuns_convert_ssdd_to_dst(&ip->saddr);
	nctuns_convert_ssdd_to_dst(&ip->daddr);

	/*
	 * Check whether the destination and the receiver are the same node.
	 */
	if (tun_net_loopback(skb, dev) != 0)
		return (0);

	/* get gateway address */
	gt = ((struct rtable*)skb->dst)->rt_gateway;

	/*
	 * Here, we should determine which type of the pkt :
	 * DirectLink or Has_DefaultGateway
	 * by ((struct rtable *)skb->dst)->rt_flags
	 *
	 * But, now, we seems just recovering gateway to ip scheme.
	 */
	nctuns_convert_ssdd_to_dst(&gt);

	/*
	 * Add local net header. If no space can be used, 
	 * allocate some.
	 */
	if((skb->data - ETH_HLEN) < skb->head)
                pskb_expand_head(skb, ETH_HLEN, 0, GFP_KERNEL);
	
	eh = (struct ethhdr *)skb_push(skb, ETH_HLEN);
	eh->h_proto = htons(ETH_P_IP);
	memcpy(eh->h_source, tun->dev->dev_addr, ETH_ALEN);

	/*
	 * Check whether the destination address is a 
	 * broadcast/multicast/unicast address.
	 * by skb->pkt_type
	 *
	 * But, now, we seems just filling gateway ip in of destination
	 * of ether header
	 */
	memcpy(eh->h_dest, &(gt), sizeof(&gt));

	/* Queue packet */
	skb_queue_tail(&tun->readq, skb);
	dev->trans_start = NCTUNS_ticks;

	/*
	 * for mmap
	 */
	//tunif_qlen[tun->tid] = skb_queue_len(&tun->readq);
	tunif_qlen[tun->tid]++;

	/*
	 * add a event into event_tun
	 */
	if (skb_queue_len(&t0p->readq) >= t0p->dev->tx_queue_len) {
		Nprintk_warning("event tunnel queue full !!\n");
		t0p->dev->stats.tx_dropped++;
		return 0;
	}
	else {
		struct tun_event	*tep;
		struct sk_buff          *tep_skb;

		if (!(tep_skb = alloc_skb(sizeof(struct tun_event), GFP_ATOMIC))) {
			t0p->dev->stats.tx_dropped++;
			return -ENOMEM;
		}

		tep = (struct tun_event *)skb_put(tep_skb, sizeof(struct tun_event));
		tep->pid   = current->pid;
		tep->nid   = nctuns_task_node_id(current);
		tep->flag  = T0E_CHKTUN;
		tep->value = tun->tid;
		tep_skb->dev = t0p->dev;

		skb_queue_tail(&t0p->readq, tep_skb);
		//*ce_tun_qlen = skb_queue_len(&t0p->readq);
		(*ce_tun_qlen)++;
	}

	/* Notify and wake up reader process */
	if (tun->flags & TUN_FASYNC)
		kill_fasync(&tun->fasync, SIGIO, POLL_IN);
	wake_up_interruptible(&tun->read_wait);
	return 0;

drop:
	dev->stats.tx_dropped++;
	kfree_skb(skb);
	return 0;
}

#define MIN_MTU 68
#define MAX_MTU 65535

static int
tun_net_change_mtu(struct net_device *dev, int new_mtu)
{
	if (new_mtu < MIN_MTU || new_mtu + dev->hard_header_len > MAX_MTU)
		return -EINVAL;
	dev->mtu = new_mtu;
	return 0;
}

/* Initialize net device. */
static void tun_net_init(struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);
	int i;

	/* Point-to-Point TUN Device */

	/*
	 * for event tunnel
	 */
	if (!strncmp(dev->name, EVENT_TUN_NAME, strlen(EVENT_TUN_NAME))) {
		i = EVENT_TUN_ID;
		tunctl_ec = tun;
		/* Zero header length */
		dev->type = ARPHRD_NONE;
		dev->hard_header_len = 0;
		dev->addr_len = 0;

		dev->tx_queue_len = 20000;
	}
	/*
	 * tunnel interface of host in topology, but tun0 is ready for tcpdump
	 */
	else {
		i = simple_strtol(dev->name + 3, NULL, 0);

		tunctl[i] = tun;

		/* Ether header length */
		dev->type = ARPHRD_ETHER; 
		dev->hard_header_len = ETH_HLEN;
		dev->addr_len = ETH_ALEN;

		dev->tx_queue_len = 1000;
	}

	/* setup the tunnel id */
	tun->tid = i;

	/* setting default mtu is 1500 */
	dev->mtu = ETH_DATA_LEN;
	dev->change_mtu = tun_net_change_mtu;

	/*
	 * initial tunnel setting and let disabled arp function, let
	 * our arp module to handle this machanism
	 */
	dev->flags = IFF_POINTOPOINT | IFF_NOARP;
}

/* Character device part */

/* Poll */
static unsigned int tun_chr_poll(struct file *file, poll_table * wait)
{
	struct tun_struct *tun = file->private_data;
	unsigned int mask = POLLOUT | POLLWRNORM;

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_chr_poll\n", tun->dev->name);

	poll_wait(file, &tun->read_wait, wait);

	if (!skb_queue_empty(&tun->readq))
		mask |= POLLIN | POLLRDNORM;

	return mask;
}

/* prepad is the amount to reserve at front.  len is length after that.
 * linear is a hint as to how much to copy (usually headers). */
static struct sk_buff *tun_alloc_skb(size_t prepad, size_t len, size_t linear,
				     gfp_t gfp)
{
	struct sk_buff *skb;
	unsigned int i;

	skb = alloc_skb(prepad + len, gfp|__GFP_NOWARN);
	if (skb) {
		skb_reserve(skb, prepad);
		skb_put(skb, len);
		return skb;
	}

	/* Under a page?  Don't bother with paged skb. */
	if (prepad + len < PAGE_SIZE)
		return NULL;

	/* Start with a normal skb, and add pages. */
	skb = alloc_skb(prepad + linear, gfp);
	if (!skb)
		return NULL;

	skb_reserve(skb, prepad);
	skb_put(skb, linear);

	len -= linear;

	for (i = 0; i < MAX_SKB_FRAGS; i++) {
		skb_frag_t *f = &skb_shinfo(skb)->frags[i];

		f->page = alloc_page(gfp|__GFP_ZERO);
		if (!f->page)
			break;

		f->page_offset = 0;
		f->size = PAGE_SIZE;

		skb->data_len += PAGE_SIZE;
		skb->len += PAGE_SIZE;
		skb->truesize += PAGE_SIZE;
		skb_shinfo(skb)->nr_frags++;

		if (len < PAGE_SIZE) {
			len = 0;
			break;
		}
		len -= PAGE_SIZE;
	}

	/* Too large, or alloc fail? */
	if (unlikely(len)) {
		kfree_skb(skb);
		skb = NULL;
	}

	return skb;
}

/* Examine the sk_buff whether is sniffer packet */
static __inline__ ssize_t tun_get_user_packet_rcv(struct sk_buff *skb, size_t len)
{
	u_char 	*ptr;
	int srcnid = 0, dstnid = 0;

	/*
	 * this tunnel ID is zero, send the packet into packet_rcv function
	 */
	if (strncmp(skb->dev->name, "tun0", 4) != 0)
		return (0);

	ptr = skb->data;
	srcnid = ptr[len - 2];
	dstnid = ptr[len - 1];

	skb->pkt_type = PACKET_TUN0;

	if (srcnid)
		skb->dev = tunctl[srcnid]->dev;
	else
		skb->dev = tunctl[dstnid]->dev;

	nctuns_packet_rcv(skb, skb->dev);

	return (1);
}

/* Get packet from user space buffer */
static __inline__ ssize_t tun_get_user(struct tun_struct *tun, struct iovec *iv, size_t count)
{
	struct sk_buff *skb;
	size_t len = count, align = 0;
	struct virtio_net_hdr gso = { 0 };

	/*
	 * if packet data will push to user space, then it will through this
	 * function, those variables are used by following code for NCTUns.
	 */
	unsigned long tun_nid, dst_nid;
	struct iphdr *ip;
	__u32 tun_ip;

	/*
	 * the event tunnel is just for sending timeout event to NCTUns engine,
	 * it shouldn't be writted by user-level program
	 */
	if (tun->tid == EVENT_TUN_ID)
		goto out;

	if (!(skb = tun_alloc_skb(align, len, gso.hdr_len, GFP_KERNEL))) {
		tun->dev->stats.rx_dropped++;
		return -ENOMEM;
	}

	if (skb_copy_datagram_from_iovec(skb, 0, iv, len)) {
		tun->dev->stats.rx_dropped++;
		kfree_skb(skb);
		return -EFAULT;
	}

	skb->dev = tun->dev;
	skb_reset_mac_header(skb);
	skb->protocol = __constant_htons(ETH_P_IP);

	if (tun->flags & TUN_NOCHECKSUM)
		skb->ip_summed = CHECKSUM_UNNECESSARY;

	/*
	 * if packet data will push to kernel space, then it will through this
	 * function
	 */
	if (tun_get_user_packet_rcv(skb, len) != 0)
		return count;

	/*
	 * get the interface IP of the tunnel device
	 */
	do {
		struct in_device        *in_dev;
		struct in_ifaddr        *ifa;

		in_dev = in_dev_get(tun->dev);
		if (!in_dev || !(ifa = in_dev->ifa_list)) {
			Nprintk_err("cannot find the interface IP of the tunnel, %s.\n", tun->dev->name);
			goto kfree_out;
		}
		else
			in_dev_put(in_dev);

		tun_ip = ifa->ifa_local;
	} while (0);

	ip = (struct iphdr *)skb->data;

	/*
	 * When this function is called, we should modify
	 * the first two bytes of source & destination address
	 * fields in IP header. Example:
	 * 
	 * src: 1.0.1.1
	 * dst: 1.0.1.3
	 *
	 * if received by tunnel 3 with ip address 1.0.1.3, 
	 * we should modify it to:
	 *
	 * src: 1.3.1.1
	 * dst: 1.3.1.3
	 */

	/* the pkt's source address */
	/*
	 * We should have two result either interval or external network. One
	 * is that this packet's destination is the interface's owner, the
	 * other is that the packet need forward to next hop. However, the
	 * first situation have two different case. One is the unicast to this
	 * node, the other is broadcast to all nodes of the subnet. Hance, we
	 * need convert the source IP to D.D.S.S (S.S.D.D, the S.S is this
	 * node) format, because of the ack or the or others mechanism maybe
	 * take the source IP to send trace-back packet to the sender.
	 *
	 * When we have the other case (forward), looking up routing tables
	 * don't need source IP, but the rt_hash table will pick the source IP
	 * to create the index key.
	 */
	ip->saddr = nctuns_convert_ip_to_ssdd(tun_ip, ip->saddr);

	/*
	 * Check to see if the node ID of the destination address
	 * equal to this tunnel's node. If yes, 
	 * we need convert the destination address of ip header to
	 * 1.0.X.X scheme, or we must change the first two bytes of
	 * destination address to be the last two bytes of this tunnel
	 * IP.
	 */
	nctuns_convert_ssdd_to_dst(&ip->daddr);

	tun_nid = mt_iptonid(tun_ip);
	dst_nid = mt_iptonid(ip->daddr);

	/*
	 *  the nodeID of this tunnel or destination is zero, that's meaning
	 *  those IP are not in NCTUns internal topology, don't modify
	 *  anythings and bypass it
	 */
	if (!tun_nid || !dst_nid)
		goto bypass;

	/*
	 * the host of the tunnel is this packet's destination, convert the
	 * ip->daddr to 1.0.X.X scheme
	 */
	if (tun_nid != dst_nid)
		ip->daddr = nctuns_convert_ip_to_ssdd(tun_ip, ip->daddr);

bypass:
	/*
	 * Check if the dst addr is a broadcast ip and it is at the
	 * same subnet.
	 */
	if ((ip->daddr & 0x00FFFFFF) == (tun_ip & 0x00FFFFFF) && ((u_char *)&ip->daddr)[3] == 255)
		skb->pkt_type = PACKET_BROADCAST;

	netif_rx_ni(skb);
	tun->dev->last_rx = NCTUNS_ticks;

	tun->dev->stats.rx_packets++;
	tun->dev->stats.rx_bytes += len;

	return count;

kfree_out:
	kfree(skb);
out:
	tun->dev->stats.rx_dropped++;
	return -EFAULT;
}

static inline size_t iov_total(const struct iovec *iv, unsigned long count)
{
	unsigned long i;
	size_t len;

	for (i = 0, len = 0; i < count; i++)
		len += iv[i].iov_len;

	return len;
}

static ssize_t tun_chr_aio_write(struct kiocb *iocb, const struct iovec *iv,
			      unsigned long count, loff_t pos)
{
	struct tun_struct *tun = iocb->ki_filp->private_data;

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_chr_write %ld\n", tun->dev->name, count);

	return tun_get_user(tun, (struct iovec *) iv, iov_total(iv, count));
}

/* Put packet to the user space buffer */
static __inline__ ssize_t tun_put_user(struct tun_struct *tun,
				       struct sk_buff *skb,
				       struct iovec *iv, int len)
{
	ssize_t total = 0;

	len = min_t(int, skb->len, len);

	skb_copy_datagram_iovec(skb, 0, iv, len);
	total += len;

	tun->dev->stats.tx_packets++;
	tun->dev->stats.tx_bytes += len;

	return total;
}

static ssize_t tun_chr_aio_read(struct kiocb *iocb, const struct iovec *iv,
			    unsigned long count, loff_t pos)
{
	struct file *file = iocb->ki_filp;
	struct tun_struct *tun = file->private_data;
	DECLARE_WAITQUEUE(wait, current);
	struct sk_buff *skb;
	ssize_t len, ret = 0;
	u_int32_t *tun_qlen;

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_chr_read\n", tun->dev->name);

	len = iov_total(iv, count);
	if (len < 0)
		return -EINVAL;

	add_wait_queue(&tun->read_wait, &wait);
	while (len) {
		current->state = TASK_INTERRUPTIBLE;

		/* Read frames from the queue */
		if (!(skb=skb_dequeue(&tun->readq))) {
			/*
			 * if the skb_queue is empty and queue length is not
			 * zero, that's meaning the queue length counter is not
			 * sync with skb_queue.
			 */
			if (tun->tid == EVENT_TUN_ID && (*ce_tun_qlen) > 0) 
				Nprintk_warning("ce_tun_qlen = %u, but no pkt in snd queue !!\n", *ce_tun_qlen);
			else if (tun->tid <= MAX_NUM_IF_TUN && tunif_qlen[tun->tid] > 0)
				Nprintk_warning("tunif_qlen[%lu] = %u, but no pkt in snd queue !!\n", tun->tid, tunif_qlen[tun->tid]);

			ret = -EAGAIN;
			break;
		}
		netif_wake_queue(tun->dev);

		ret = tun_put_user(tun, skb, (struct iovec *) iv, len);
		kfree_skb(skb);
		break;
	}

	/*
	 * for mmap, sync the queue length
	 */
	if (tun->tid == EVENT_TUN_ID)
		tun_qlen = ce_tun_qlen;
	else
		tun_qlen = &tunif_qlen[tun->tid];

	//(*tun_qlen) = skb_queue_len(&tun->readq);
	(*tun_qlen)--;

	current->state = TASK_RUNNING;
	remove_wait_queue(&tun->read_wait, &wait);

	return ret;
}

static void tun_setup(struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);

	skb_queue_head_init(&tun->readq);
	init_waitqueue_head(&tun->read_wait);

	tun->owner = -1;
	tun->group = -1;

	dev->open = tun_net_open;
	dev->hard_start_xmit = tun_net_xmit;
	dev->stop = tun_net_close;
	dev->ethtool_ops = &tun_ethtool_ops;
	dev->destructor = free_netdev;
	dev->features |= NETIF_F_NETNS_LOCAL;
}

static struct tun_struct *tun_get_by_name(struct tun_net *tn, const char *name)
{
	struct tun_struct *tun;

	ASSERT_RTNL();
	list_for_each_entry(tun, &tn->dev_list, list) {
		if (!strncmp(tun->dev->name, name, IFNAMSIZ))
		    return tun;
	}

	return NULL;
}

static int tun_set_iff(struct net *net, struct file *file, struct ifreq *ifr)
{
	struct tun_net *tn;
	struct tun_struct *tun;
	struct net_device *dev;
	int err;

	tn = net_generic(net, tun_net_id);
	tun = tun_get_by_name(tn, ifr->ifr_name);
	if (tun) {
		if (tun->attached)
			return -EBUSY;

		/* Check permissions */
		if (((tun->owner != -1 &&
		      current->euid != tun->owner) ||
		     (tun->group != -1 &&
		      current->egid != tun->group)) &&
		     !capable(CAP_NET_ADMIN))
			return -EPERM;
	}
	else if (__dev_get_by_name(net, ifr->ifr_name))
		return -EINVAL;
	else {
		char *name;
		unsigned long flags = 0;

		err = -EINVAL;

		if (!capable(CAP_NET_ADMIN))
			return -EPERM;

		/* Set dev type be TUN device */
		flags |= TUN_TUN_DEV;
		name = "tun%d";

		if (*ifr->ifr_name)
			name = ifr->ifr_name;

		dev = alloc_netdev(sizeof(struct tun_struct), name,
				   tun_setup);
		if (!dev)
			return -ENOMEM;

		dev_net_set(dev, net);
		tun = netdev_priv(dev);
		tun->dev = dev;
		tun->flags = flags;
		tun->txflt.count = 0;

		tun_net_init(dev);

		if (strchr(dev->name, '%')) {
			err = dev_alloc_name(dev, dev->name);
			if (err < 0)
				goto err_free_dev;
		}

		err = register_netdevice(tun->dev);
		if (err < 0)
			goto err_free_dev;

		list_add(&tun->list, &tn->dev_list);
	}

	DBG(KERN_INFO "%s: tun_set_iff\n", tun->dev->name);

	/* 
	 * phy module and routing daemon can use ioctl()
	 * to set or get the flag. Having this info., they
	 * can judge the interface's state(up or down).
	 */
	tun->flags |= TUN_UP;

	/*
	 * We always ignore the checksum.
	 */
	tun->flags |= TUN_NOCHECKSUM;

	file->private_data = tun;
	tun->attached = 1;
	get_net(dev_net(tun->dev));

	/* Make sure persistent devices do not get stuck in
	 * xoff state.
	 */
	if (netif_running(tun->dev))
		netif_wake_queue(tun->dev);

	strcpy(ifr->ifr_name, tun->dev->name);
	return 0;

err_free_dev:
	free_netdev(dev);
	return err;
}

static int tun_get_iff(struct net *net, struct file *file, struct ifreq *ifr)
{
	struct tun_struct *tun = file->private_data;

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_get_iff\n", tun->dev->name);

	strcpy(ifr->ifr_name, tun->dev->name);

	ifr->ifr_flags = 0;

	ifr->ifr_flags |= IFF_TUN;

	return 0;
}

/* This is like a cut-down ethtool ops, except done via tun fd so no
 * privs required. */
static int set_offload(struct net_device *dev, unsigned long arg)
{
	unsigned int old_features, features;

	old_features = dev->features;
	/* Unset features, set them as we chew on the arg. */
	features = (old_features & ~(NETIF_F_HW_CSUM|NETIF_F_SG|NETIF_F_FRAGLIST
				    |NETIF_F_TSO_ECN|NETIF_F_TSO|NETIF_F_TSO6));

	if (arg & TUN_F_CSUM) {
		features |= NETIF_F_HW_CSUM|NETIF_F_SG|NETIF_F_FRAGLIST;
		arg &= ~TUN_F_CSUM;

		if (arg & (TUN_F_TSO4|TUN_F_TSO6)) {
			if (arg & TUN_F_TSO_ECN) {
				features |= NETIF_F_TSO_ECN;
				arg &= ~TUN_F_TSO_ECN;
			}
			if (arg & TUN_F_TSO4)
				features |= NETIF_F_TSO;
			if (arg & TUN_F_TSO6)
				features |= NETIF_F_TSO6;
			arg &= ~(TUN_F_TSO4|TUN_F_TSO6);
		}
	}

	/* This gives the user a way to test for new features in future by
	 * trying to set them. */
	if (arg)
		return -EINVAL;

	dev->features = features;
	if (old_features != dev->features)
		netdev_features_change(dev);

	return 0;
}

static int tun_chr_ioctl(struct inode *inode, struct file *file,
			 unsigned int cmd, unsigned long arg)
{
	struct tun_struct *tun = file->private_data;
	void __user* argp = (void __user*)arg;
	struct ifreq ifr;
	int ret;
	DECLARE_MAC_BUF(mac);

	if (cmd == TUNSETIFF || _IOC_TYPE(cmd) == 0x89)
		if (copy_from_user(&ifr, argp, sizeof ifr))
			return -EFAULT;

	if (cmd == TUNSETIFF && !tun) {
		int err;

		ifr.ifr_name[IFNAMSIZ-1] = '\0';

		rtnl_lock();
		err = tun_set_iff(current->nsproxy->net_ns, file, &ifr);
		rtnl_unlock();

		if (err)
			return err;

		if (copy_to_user(argp, &ifr, sizeof(ifr)))
			return -EFAULT;
		return 0;
	}

	if (cmd == TUNGETFEATURES) {
		/* Currently this just means: "what IFF flags are valid?".
		 * This is needed because we never checked for invalid flags on
		 * TUNSETIFF. */
		return put_user(IFF_TUN | IFF_TAP | IFF_NO_PI | IFF_ONE_QUEUE |
				IFF_VNET_HDR,
				(unsigned int __user*)argp);
	}

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_chr_ioctl cmd %d\n", tun->dev->name, cmd);

	switch (cmd) {
		case TUNGETIFF:
			ret = tun_get_iff(current->nsproxy->net_ns, file, &ifr);
			if (ret)
				return ret;

			if (copy_to_user(argp, &ifr, sizeof(ifr)))
				return -EFAULT;
			break;

		case TUNSETNOCSUM:
			/* Disable/Enable checksum */
			if (arg)
				tun->flags |= TUN_NOCHECKSUM;
			else
				tun->flags &= ~TUN_NOCHECKSUM;

			DBG(KERN_INFO "%s: checksum %s\n",
					tun->dev->name, arg ? "disabled" : "enabled");
			break;

		case TUNSETPERSIST:
			/* Disable/Enable persist mode */
			if (arg)
				tun->flags |= TUN_PERSIST;
			else
				tun->flags &= ~TUN_PERSIST;

			DBG(KERN_INFO "%s: persist %s\n",
					tun->dev->name, arg ? "enabled" : "disabled");
			break;

		case TUNSETOWNER:
			/* Set owner of the device */
			tun->owner = (uid_t) arg;

			DBG(KERN_INFO "%s: owner set to %d\n", tun->dev->name, tun->owner);
			break;

		case TUNSETGROUP:
			/* Set group of the device */
			tun->group= (gid_t) arg;

			DBG(KERN_INFO "%s: group set to %d\n", tun->dev->name, tun->group);
			break;

		case TUNSETLINK:
			/* Only allow setting the type when the interface is down */
			rtnl_lock();
			if (tun->dev->flags & IFF_UP) {
				DBG(KERN_INFO "%s: Linktype set failed because interface is up\n",
						tun->dev->name);
				ret = -EBUSY;
			} else {
				tun->dev->type = (int) arg;
				DBG(KERN_INFO "%s: linktype set to %d\n", tun->dev->name, tun->dev->type);
				ret = 0;
			}
			rtnl_unlock();
			return ret;

			/*
			 * create two command to changed the link up and down state for NCTUns
			 * simulator
			 */
		case TUNSETUD: {
				       unsigned long flag;

				       if (copy_from_user(&flag, (void *)arg, sizeof(flag)))
					       return -EFAULT;

				       tun->flags &= 0x0fff;
				       tun->flags |= flag;

				       //ystseng: 06/04/27 adaptation
				       if (copy_to_user((void *)argp, &flag, sizeof(flag)))
					       return -EFAULT;
				       break;
			       }

		case TUNGETUD: {
				       unsigned long flag = tun->flags & 0xf000;

				       //ystseng: 06/04/27 adaptation
				       if (copy_to_user((void *)argp, &flag, sizeof(flag)))
					       return -EFAULT;
				       break;
			       }

#ifdef TUN_DEBUG
		case TUNSETDEBUG:
			       tun->debug = arg;
			       break;
#endif
		case TUNSETOFFLOAD:
			       rtnl_lock();
			       ret = set_offload(tun->dev, arg);
			       rtnl_unlock();
			       return ret;

		case TUNSETTXFILTER:
			       /* Can be set only for TAPs */
			       if ((tun->flags & TUN_TYPE_MASK) != TUN_TAP_DEV)
				       return -EINVAL;
			       rtnl_lock();
			       ret = update_filter(&tun->txflt, (void __user *)arg);
			       rtnl_unlock();
			       return ret;

		case SIOCGIFHWADDR:
			       /* Get hw addres */
			       memcpy(ifr.ifr_hwaddr.sa_data, tun->dev->dev_addr, ETH_ALEN);
			       ifr.ifr_hwaddr.sa_family = tun->dev->type;
			       if (copy_to_user(argp, &ifr, sizeof ifr))
				       return -EFAULT;
			       return 0;

		case SIOCSIFHWADDR:
			       /* Set hw address */
			       DBG(KERN_DEBUG "%s: set hw address: %s\n",
					       tun->dev->name, print_mac(mac, ifr.ifr_hwaddr.sa_data));

			       rtnl_lock();
			       ret = dev_set_mac_address(tun->dev, &ifr.ifr_hwaddr);
			       rtnl_unlock();
			       return ret;

		default:
			       return -EINVAL;
	};

	return 0;
}

static int tun_chr_fasync(int fd, struct file *file, int on)
{
	struct tun_struct *tun = file->private_data;
	int ret;

	if (!tun)
		return -EBADFD;

	DBG(KERN_INFO "%s: tun_chr_fasync %d\n", tun->dev->name, on);

	lock_kernel();
	if ((ret = fasync_helper(fd, file, on, &tun->fasync)) < 0)
		goto out;

	if (on) {
		ret = __f_setown(file, task_pid(current), PIDTYPE_PID, 0);
		if (ret)
			goto out;
		tun->flags |= TUN_FASYNC;
	} else
		tun->flags &= ~TUN_FASYNC;
	ret = 0;
out:
	unlock_kernel();
	return ret;
}

static int tun_chr_open(struct inode *inode, struct file * file)
{
	cycle_kernel_lock();
	DBG1(KERN_INFO "tunX: tun_chr_open\n");
	file->private_data = NULL;
	return 0;
}

static int tun_chr_close(struct inode *inode, struct file *file)
{
	struct tun_struct *tun = file->private_data;

	if (!tun)
		return 0;

	DBG(KERN_INFO "%s: tun_chr_close\n", tun->dev->name);

	rtnl_lock();

	/* Detach from net device */
	file->private_data = NULL;
	tun->attached = 0;
	put_net(dev_net(tun->dev));
	/* cleanup the event tunnel pointer */
	if (tun->tid == EVENT_TUN_ID) {
		tunctl_ec = NULL;
		(*ce_tun_qlen) = 0;
	}
	else {
		tunctl[tun->tid] = NULL;
		tunif_qlen[tun->tid] = 0;
	}

	/* Drop read queue */
	skb_queue_purge(&tun->readq);

	if (!(tun->flags & TUN_PERSIST)) {
		list_del(&tun->list);
		unregister_netdevice(tun->dev);
	}

	rtnl_unlock();

	return 0;
}

static const struct file_operations nctuns_tun_fops = {
	.owner	= THIS_MODULE,
	.llseek = no_llseek,
	.read  = do_sync_read,
	.aio_read  = tun_chr_aio_read,
	.write = do_sync_write,
	.aio_write = tun_chr_aio_write,
	.poll	= tun_chr_poll,
	.ioctl	= tun_chr_ioctl,
	.open	= tun_chr_open,
	.release = tun_chr_close,
	.fasync = tun_chr_fasync
};

extern unsigned int divert_hook(unsigned int hook, 
		struct sk_buff *pskb, 
		const struct net_device *indev, 
		const struct net_device *outdev, 
		int (*okfn)(struct sk_buff *));

/*
 * the nf_hook_ops data_struct are used for register nf_hook to support divert
 * socket
 */
static struct nf_hook_ops divert_ops[] =
{
	{
		.hook		= divert_hook, 
		.owner		= THIS_MODULE,
		.pf		= PF_INET, 
		.hooknum	= NF_INET_PRE_ROUTING,
		.priority	= NF_IP_PRI_FILTER,
	},

	{
		.hook		= divert_hook, 
		.owner		= THIS_MODULE,
		.pf		= PF_INET, 
		.hooknum	= NF_INET_LOCAL_IN,
		.priority	= NF_IP_PRI_FILTER,
	},

	{
		.hook		= divert_hook, 
		.owner		= THIS_MODULE,
		.pf		= PF_INET, 
		.hooknum	= NF_INET_FORWARD,
		.priority	= NF_IP_PRI_FILTER,
	},

	{
		.hook		= divert_hook, 
		.owner		= THIS_MODULE,
		.pf		= PF_INET, 
		.hooknum	= NF_INET_LOCAL_OUT,
		.priority	= NF_IP_PRI_FILTER,
	},

	{
		.hook		= divert_hook, 
		.owner		= THIS_MODULE,
		.pf		= PF_INET, 
		.hooknum	= NF_INET_POST_ROUTING,
		.priority	= NF_IP_PRI_FILTER,
	},
};

/* ethtool interface */

static int tun_get_settings(struct net_device *dev, struct ethtool_cmd *cmd)
{
	cmd->supported		= 0;
	cmd->advertising	= 0;
	cmd->speed		= SPEED_10;
	cmd->duplex		= DUPLEX_FULL;
	cmd->port		= PORT_TP;
	cmd->phy_address	= 0;
	cmd->transceiver	= XCVR_INTERNAL;
	cmd->autoneg		= AUTONEG_DISABLE;
	cmd->maxtxpkt		= 0;
	cmd->maxrxpkt		= 0;
	return 0;
}

static void tun_get_drvinfo(struct net_device *dev, struct ethtool_drvinfo *info)
{
	strcpy(info->driver, DRV_NAME);
	strcpy(info->version, DRV_VERSION);
	strcpy(info->fw_version, "N/A");
	strcpy(info->bus_info, "tun");
}

static u32 tun_get_msglevel(struct net_device *dev)
{
#ifdef TUN_DEBUG
	struct tun_struct *tun = netdev_priv(dev);
	return tun->debug;
#else
	return -EOPNOTSUPP;
#endif
}

static void tun_set_msglevel(struct net_device *dev, u32 value)
{
#ifdef TUN_DEBUG
	struct tun_struct *tun = netdev_priv(dev);
	tun->debug = value;
#endif
}

static u32 tun_get_link(struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);
	return tun->attached;
}

static u32 tun_get_rx_csum(struct net_device *dev)
{
	struct tun_struct *tun = netdev_priv(dev);
	return (tun->flags & TUN_NOCHECKSUM) == 0;
}

static int tun_set_rx_csum(struct net_device *dev, u32 data)
{
	struct tun_struct *tun = netdev_priv(dev);
	if (data)
		tun->flags &= ~TUN_NOCHECKSUM;
	else
		tun->flags |= TUN_NOCHECKSUM;
	return 0;
}

static const struct ethtool_ops tun_ethtool_ops = {
	.get_settings	= tun_get_settings,
	.get_drvinfo	= tun_get_drvinfo,
	.get_msglevel	= tun_get_msglevel,
	.set_msglevel	= tun_set_msglevel,
	.get_link	= tun_get_link,
	.get_rx_csum	= tun_get_rx_csum,
	.set_rx_csum	= tun_set_rx_csum
};

/*
 * the character device struct and the sysfs class of this device
 */

static struct cdev nctuns_cdev = {
	.kobj	= { .name = DRV_NAME },
	.owner	= THIS_MODULE
};
static dev_t nctuns_dev_t;
static struct class *nctuns_class;

static int tun_init_net(struct net *net)
{
	struct tun_net *tn;

	tn = kmalloc(sizeof(*tn), GFP_KERNEL);
	if (tn == NULL)
		return -ENOMEM;

	INIT_LIST_HEAD(&tn->dev_list);

	if (net_assign_generic(net, tun_net_id, tn)) {
		kfree(tn);
		return -ENOMEM;
	}

	return 0;
}

static void tun_exit_net(struct net *net)
{
	struct tun_net *tn;
	struct tun_struct *tun, *nxt;

	tn = net_generic(net, tun_net_id);

	rtnl_lock();
	list_for_each_entry_safe(tun, nxt, &tn->dev_list, list) {
		DBG(KERN_INFO "%s cleaned up\n", tun->dev->name);
		unregister_netdevice(tun->dev);
	}
	rtnl_unlock();

	kfree(tn);
}

static struct pernet_operations tun_net_ops = {
	.init = tun_init_net,
	.exit = tun_exit_net,
};

static int __init tun_init(void)
{
	int i, ret;

	/*
	 * initialize the tunctl pointer
	 */
	ret = 0;
	tunctl_ec = NULL;
	memset(tunctl, 0, sizeof(uint32_t) * MAX_NUM_TUN);

	ret = register_pernet_gen_device(&tun_net_id, &tun_net_ops);
	if (ret) {
		printk(KERN_ERR "tun: Can't register pernet ops\n");
		goto err_pernet;
	}

	/*
	 * allocate device number and initialize the cdev struct for nctuns_tun
	 */
	ret = alloc_chrdev_region(&nctuns_dev_t, 0, MAX_NCTUNS_TUN_MIXORS, DRV_NAME);

	if (ret) {
		Nprintk_err(DRV_NAME ": Can't allocation the device number.\n");
		goto error;
	}

	cdev_init(&nctuns_cdev, &nctuns_tun_fops);
	ret = cdev_add(&nctuns_cdev, nctuns_dev_t, MAX_NCTUNS_TUN_MIXORS);
	if (ret) {
		Nprintk_err(DRV_NAME ": Can't add the cdev.\n");
		kobject_put(&nctuns_cdev.kobj);
		goto error_region;
	}

	/*
	 * create a class of sysfs for nctuns, and create a device node for nctuns_tun
	 */
	nctuns_class = class_create(THIS_MODULE, "nctuns");
	if (IS_ERR(nctuns_class)) {
		Nprintk_err(DRV_NAME ": Error creating nctuns class.\n");
		ret = PTR_ERR(nctuns_class);
		goto error_region;
	}

	device_create(nctuns_class, NULL, nctuns_dev_t, NULL, DRV_NAME);

	/*
	 * Register hooks.
	 * This is uesed by emulation daemon and mobile ip daemon.
	 */
	for (i = 0; i < NF_INET_NUMHOOKS; i++) 
		INIT_LIST_HEAD(&rule_table[i]);

	ret = nf_register_hooks(divert_ops, ARRAY_SIZE(divert_ops));
	if (ret < 0) {
		Nprintk_err(DRV_NAME ": can't register hooks for divert socket.\n");
		goto error_class;
	}

	Nprintk_info(DRV_NAME ": %s, %s\n", DRV_DESCRIPTION, DRV_VERSION);
	Nprintk_info(DRV_NAME ": %s\n", DRV_COPYRIGHT);

	return (0);

error_class:
	device_destroy(nctuns_class, nctuns_dev_t);
	class_destroy(nctuns_class);
	cdev_del(&nctuns_cdev);
error_region:
	unregister_chrdev_region(nctuns_dev_t, MAX_NCTUNS_TUN_MIXORS);
error:
	unregister_pernet_gen_device(tun_net_id, &tun_net_ops);
err_pernet:
	return ret;
}

static void tun_cleanup(void)
{
	/*
	 * unregister the device number of nctuns_tun and destroy the nctuns of
	 * sysfs
	 */
	device_destroy(nctuns_class, nctuns_dev_t);
	class_destroy(nctuns_class);
	cdev_del(&nctuns_cdev);
	unregister_chrdev_region(nctuns_dev_t, MAX_NCTUNS_TUN_MIXORS);

	/*
	 * Unregister hooks
	 */
	nf_unregister_hooks(divert_ops, ARRAY_SIZE(divert_ops));

	/*
	 * Unregister all network devices
	 */
	unregister_pernet_gen_device(tun_net_id, &tun_net_ops);
}

module_init(tun_init);
module_exit(tun_cleanup);

MODULE_DESCRIPTION(DRV_DESCRIPTION);
MODULE_AUTHOR(DRV_COPYRIGHT);
MODULE_VERSION(DRV_VERSION);
MODULE_LICENSE("GPL");
