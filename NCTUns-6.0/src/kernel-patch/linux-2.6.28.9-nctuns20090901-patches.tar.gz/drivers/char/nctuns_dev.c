#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/mman.h>
#include <asm/io.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/cdev.h>

#include <linux/types.h>
#include <nctuns/nctuns_kernel.h>

#define NCTUNS_DEV_NAME "nctuns_dev"
#define NCTUNS_DEV_MAJOR 0

//static DEFINE_SPINLOCK(nctuns_dev_lock);
//unsigned int		nctuns_major;
//use sysfs start
static dev_t 		nctuns_dev_dev_t;
//use sysfs end
static int		device_open_num;

struct nctuns_dev{
	u64             NCTUNS_nodeVC[2];
	uint32_t        tunif_qlen[MAX_NUM_TUN];
	uint32_t        ce_tun_qlen;
	uint32_t        fifoIFmaxqlen[MAX_NUM_TUN];
	uint32_t        fifoIFcurqlen[MAX_NUM_TUN];
};

static struct nctuns_dev *dev_ptr = NULL;
static struct nctuns_dev *dev_area = NULL;

#ifndef VMALLOC_VMADDR
#define VMALLOC_VMADDR(x) ((unsigned long)(x))
#endif

/* ===================================================================== *
 * the following global variable will be used for memory mapping.        *
 * ===================================================================== */

/*
 * The virtual clock of nodes. In the current version, we use only node 0's
 * clock as the whole simulation system's clock.
 */
u64             *NCTUNS_nodeVC = NULL;

/*
 * the current nctuns and event tunnel queue length, the NCTUns engine just
 * read only
 */
uint32_t        *tunif_qlen = NULL;
uint32_t        *ce_tun_qlen = NULL;

/*
 * the current fifo queue length and max queue length of NCTUns engine, the
 * kernel just read only
 */
uint32_t        *fifoIFmaxqlen = NULL;
uint32_t        *fifoIFcurqlen = NULL;


// From: http://www.scs.ch/~frey/linux/memorymap.html
volatile void *virt_to_kseg(volatile void *address) {
	pgd_t *pgd; pmd_t *pmd; pte_t *ptep, pte;
	unsigned long va, ret = 0UL;
	va=VMALLOC_VMADDR((unsigned long)address);
	/* get the page directory. Use the kernel memory map. */
	pgd = pgd_offset_k(va);
	/* check whether we found an entry */
	if (!pgd_none(*pgd)) {
		// I'm not sure if we need this, or the line for 2.4
		//    above will work reliably too
		// If you know, please email me :-)
		pud_t *pud = pud_offset(pgd, va);		
		pmd = pmd_offset(pud, va);
		/* check whether we found an entry */
		if (!pmd_none(*pmd)) {
			/* get a pointer to the page table entry */
			ptep = pte_offset_map(pmd, va);
			pte = *ptep;
			/* check for a valid page */
			if (pte_present(pte)) {
				/* get the address the page is refering to */
				ret = (unsigned long)page_address(pte_page(pte));
				/* add the offset within the page to the page address */
				ret |= (va & (PAGE_SIZE -1));
			}
		}
	}
	return((volatile void *)ret);
}

static int nctuns_mmap(struct file *filp, struct vm_area_struct *vma)
{
	int ret;
	//printk("[NCTUNS_DEV] use mmap function\n");

	ret = remap_pfn_range(vma,
			vma->vm_start,
			virt_to_phys((void*)((unsigned long)dev_area)) >> PAGE_SHIFT,
			vma->vm_end-vma->vm_start,
			PAGE_SHARED);
	//               vma->vm_page_prot);
	if(ret != 0) {
		return -EAGAIN;
	}
	return 0;

}

static int nctuns_open(struct inode *inode, struct file *filp)
{
	//spin_lock(&nctuns_dev_lock);
	device_open_num ++;
	//spin_unlock(&nctuns_dev_lock);
	//printk("[NCTUNS_DEV] open nctuns device system call (%d)\n", device_open_num);
	return 0; 
}

static int nctuns_release(struct inode *inode, struct file *filp)
{
	//spin_lock(&nctuns_dev_lock);
	device_open_num --;
	//spin_unlock(&nctuns_dev_lock);

	//if(device_open_num == 0);
	return 0;
}

static struct file_operations nctuns_dev_fops = {
	.owner          = THIS_MODULE,
	.open		= nctuns_open,
	.release	= nctuns_release,
	.mmap		= nctuns_mmap,
};

static struct cdev nctuns_dev_cdev = {
	.kobj   = { .name = NCTUNS_DEV_NAME },
	.owner  = THIS_MODULE
};

static struct class *nctuns_dev_class;

static int __init nctuns_init(void)
{
	unsigned long virt_addr;
	int ret;
	printk("Initializing NCTUns driver module\n");

	//nctuns_major = register_chrdev(NCTUNS_DEV_MAJOR, NCTUNS_DEV_NAME, &nctuns_dev_fops);
	//use sysfs start
	ret = alloc_chrdev_region(&nctuns_dev_dev_t, 0, 1, NCTUNS_DEV_NAME);
	if (ret) {
		Nprintk_err(NCTUNS_DEV_NAME ": Can't allocation the device number.\n");
		goto error;
	}

	cdev_init(&nctuns_dev_cdev, &nctuns_dev_fops);
	ret = cdev_add(&nctuns_dev_cdev, nctuns_dev_dev_t, 1);

	if (ret) {
		Nprintk_err(NCTUNS_DEV_NAME ": Can't add the cdev.\n");
		kobject_put(&nctuns_dev_cdev.kobj);
		goto error_region;
	}

	//use sysfs end
	/*printk("NCTUns driver major number = %x\n", nctuns_major);
	   if(nctuns_major < 0)
	   {
	   printk(KERN_ERR "nctuns - cannot register device\n");
	   ret = nctuns_major;
	   goto error;
	   }*/

	//sysfs start
	nctuns_dev_class = class_create(THIS_MODULE, "nctuns_dev_class");

	if (IS_ERR(nctuns_dev_class)) {
		printk("%s: Error creating nctuns_dev_class class.\n", NCTUNS_DEV_NAME);
		ret = PTR_ERR(nctuns_dev_class);
		goto error_region;
	}
	device_create(nctuns_dev_class, NULL, nctuns_dev_dev_t, NULL, NCTUNS_DEV_NAME);
	//sysfs end

	device_open_num = 0;

	dev_ptr = kmalloc(sizeof(struct nctuns_dev), GFP_KERNEL);

	if(!dev_ptr)
	{
		printk("%s: kmalloc failed\n", NCTUNS_DEV_NAME);
		ret = -EFAULT;
		goto error_class;
	}

	dev_area = (struct nctuns_dev *)(((unsigned long)dev_ptr + PAGE_SIZE -1) & PAGE_MASK);// PAGE_MASK = ~(PAGE_SIZE - 1) find the page number

	for (virt_addr=(unsigned long)dev_area; virt_addr < (unsigned long)dev_area + sizeof(struct nctuns_dev); virt_addr+=PAGE_SIZE)
		SetPageReserved(virt_to_page(virt_addr));

	printk("kmalloc_area at 0x%p (phys 0x%lx)\n", dev_area, virt_to_phys((void *)virt_to_kseg(dev_area)));

	NCTUNS_nodeVC = dev_ptr->NCTUNS_nodeVC;
	tunif_qlen    = dev_ptr->tunif_qlen;
	ce_tun_qlen   = &(dev_ptr->ce_tun_qlen);
	fifoIFmaxqlen = dev_ptr->fifoIFmaxqlen;
	fifoIFcurqlen = dev_ptr->fifoIFcurqlen;

	NCTUNS_nodeVC[0] = 100llu;
	NCTUNS_nodeVC[1] = 0;

	return 0;

error_class:
	device_destroy(nctuns_dev_class, nctuns_dev_dev_t);
	class_destroy(nctuns_dev_class);
	cdev_del(&nctuns_dev_cdev);
error_region:
	//unregister_chrdev(nctuns_major, NCTUNS_DEV_NAME);
	unregister_chrdev_region(nctuns_dev_dev_t, 1);
error:
	return ret;
}

static void __exit nctuns_cleanup(void)
{
	unsigned long virt_addr;

	for (virt_addr=(unsigned long)dev_area; virt_addr < (unsigned long)dev_area + sizeof(struct nctuns_dev); virt_addr+=PAGE_SIZE) {
		// clear all pages
		ClearPageReserved(virt_to_page(virt_addr));
	}

	kfree(dev_ptr);
	//unregister_chrdev(nctuns_major, NCTUNS_DEV_NAME);
	unregister_chrdev_region(nctuns_dev_dev_t, 1);
}

module_init(nctuns_init);
module_exit(nctuns_cleanup);

EXPORT_SYMBOL(NCTUNS_nodeVC);
EXPORT_SYMBOL(tunif_qlen);
EXPORT_SYMBOL(ce_tun_qlen);
EXPORT_SYMBOL(fifoIFmaxqlen);

MODULE_AUTHOR("WJ Hung");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("NCTUNS DIRVER FOR MMAP");
